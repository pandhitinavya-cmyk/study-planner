export type PriorityLevel = 'critical' | 'high' | 'medium' | 'low';
export type EnergyLevel = 'high' | 'normal' | 'low';
export type TaskType = 'assignment' | 'project' | 'exam_prep' | 'lab' | 'revision' | 'personal';
export type TaskStatus = 'pending' | 'in_progress' | 'completed' | 'missed' | 'partially_completed';

export interface Subtask {
  id: string;
  title: string;
  completed: boolean;
  estimatedMinutes: number;
}

export interface Task {
  id: string;
  title: string;
  type: TaskType;
  subjectId: string;
  subjectName: string;
  deadline: string; // YYYY-MM-DD
  estimatedMinutes: number;
  difficulty: 'easy' | 'medium' | 'hard';
  importance: 'critical' | 'high' | 'medium' | 'low';
  calculatedPriority: PriorityLevel;
  priorityScore: number;
  priorityReason: string;
  status: TaskStatus;
  progressPercent: number;
  scheduledDate: string; // YYYY-MM-DD
  scheduledTimeSlot?: string; // e.g. "04:00 PM - 05:30 PM"
  subtasks: Subtask[];
  notes?: string;
  examId?: string;
}

export interface Subject {
  id: string;
  name: string;
  code: string;
  color: string;
  difficulty: 'easy' | 'medium' | 'hard';
  isWeakSubject: boolean;
  confidenceScore: number; // 0 - 100
  totalHoursStudied: number;
  targetWeeklyHours: number;
  performanceRating: number; // 0 - 100
  syllabusProgress: number; // 0 - 100
}

export interface Exam {
  id: string;
  subjectId: string;
  subjectName: string;
  title: string;
  examDate: string; // YYYY-MM-DD
  daysRemaining: number;
  totalWeightage: number; // percentage
  estimatedHoursNeeded: number;
  preparedHours: number;
  syllabusTopics: string[];
  rescueModeActive?: boolean;
}

export interface StudySession {
  id: string;
  taskId: string;
  taskTitle: string;
  subjectName: string;
  subjectColor: string;
  date: string; // YYYY-MM-DD
  startTime: string; // "16:00"
  endTime: string; // "17:15"
  timeSlotString: string; // "04:00 PM - 05:15 PM"
  durationMinutes: number;
  isCompleted: boolean;
  isRescheduled?: boolean;
  rescheduleReason?: string;
}

export interface StudentProfile {
  name: string;
  course: string;
  year: string;
  semester: string;
  dailyAvailableHours: number;
  preferredStudyTime: 'morning' | 'afternoon' | 'evening' | 'night';
  currentEnergy: EnergyLevel;
  quickTimeBudget: number | null; // e.g., 2 hours today
  studyPoints: number;
  streakDays: number;
  weeklyGoalHours: number;
  onboardingCompleted: boolean;
}

export interface NotificationItem {
  id: string;
  title: string;
  message: string;
  type: 'urgent' | 'info' | 'reschedule' | 'break' | 'achievement';
  timestamp: string;
  read: boolean;
  actionText?: string;
  actionRoute?: string;
}

export interface AdaptiveRescheduleEvent {
  id: string;
  missedTaskId: string;
  taskTitle: string;
  originalSlot: string;
  newSlot: string;
  reason: string;
  message: string;
  suggestedAt: string;
}

export interface AchievementBadge {
  id: string;
  title: string;
  description: string;
  icon: string;
  unlocked: boolean;
  dateUnlocked?: string;
  progress?: number;
  maxProgress?: number;
}
