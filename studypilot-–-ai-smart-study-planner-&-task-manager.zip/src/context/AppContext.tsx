import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  StudentProfile,
  Subject,
  Exam,
  Task,
  StudySession,
  AchievementBadge,
  NotificationItem,
  AdaptiveRescheduleEvent,
  EnergyLevel,
  PriorityLevel,
  TaskStatus,
} from '../types';
import {
  initialProfile,
  initialSubjects,
  initialExams,
  initialTasks,
  initialSessions,
  initialAchievements,
  initialNotifications,
  getTodayDateString,
} from '../utils/demoData';
import { calculateTaskPriority } from '../utils/priorityEngine';
import { generateSmartSchedule, createAdaptiveRescheduleProposal } from '../utils/scheduler';

interface RecommendationResult {
  taskId?: string;
  recommendedTask: string;
  subject: string;
  suggestedMinutes: number;
  priorityLevel: PriorityLevel;
  reason: string;
  firstStep: string;
  energyFit: string;
}

interface AppContextType {
  profile: StudentProfile;
  subjects: Subject[];
  exams: Exam[];
  tasks: Task[];
  sessions: StudySession[];
  achievements: AchievementBadge[];
  notifications: NotificationItem[];
  activeRescheduleEvent: AdaptiveRescheduleEvent | null;
  activeFocusTaskId: string | null;
  currentView: string;
  theme: 'dark' | 'light';
  
  // Navigation
  setCurrentView: (view: string) => void;
  toggleTheme: () => void;

  // Profile actions
  updateProfile: (updated: Partial<StudentProfile>) => void;
  setEnergyMode: (mode: EnergyLevel) => void;
  setTimeBudget: (hours: number | null) => void;
  completeOnboarding: (data: Partial<StudentProfile>, newSubjects?: Subject[], newExams?: Exam[]) => void;
  resetToDemoData: () => void;

  // Task actions
  addTask: (taskData: Omit<Task, 'id' | 'calculatedPriority' | 'priorityScore' | 'priorityReason'>) => Task;
  updateTask: (taskId: string, updates: Partial<Task>) => void;
  deleteTask: (taskId: string) => void;
  toggleSubtask: (taskId: string, subtaskId: string) => void;
  addSubtask: (taskId: string, title: string, estimatedMinutes?: number) => void;
  markTaskStatus: (taskId: string, status: TaskStatus, remainingMins?: number) => void;

  // Subject & Exam actions
  addSubject: (subject: Omit<Subject, 'id'>) => void;
  updateSubject: (id: string, updates: Partial<Subject>) => void;
  deleteSubject: (id: string) => void;
  addExam: (exam: Omit<Exam, 'id' | 'daysRemaining'>) => void;
  updateExam: (id: string, updates: Partial<Exam>) => void;
  toggleExamRescueMode: (examId: string) => void;

  // Smart Planner actions
  regenerateSchedule: (targetDate?: string) => void;
  acceptRescheduleProposal: (proposalId: string) => void;
  dismissRescheduleProposal: () => void;

  // Focus Mode
  startFocusMode: (taskId?: string) => void;
  exitFocusMode: () => void;

  // AI Actions
  getWhatShouldIStudyNow: () => Promise<RecommendationResult>;
  requestTaskBreakdown: (title: string, subject?: string, hours?: number, notes?: string) => Promise<{ subtasks: any[]; studyTip: string }>;
  requestExamRescue: (exam: Exam, dailyHours?: number) => Promise<any>;

  // Notification actions
  markNotificationRead: (id: string) => void;
  clearNotifications: () => void;
  addNotification: (notif: Omit<NotificationItem, 'id' | 'timestamp' | 'read'>) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [profile, setProfile] = useState<StudentProfile>(() => {
    const saved = localStorage.getItem('studypilot_profile');
    return saved ? JSON.parse(saved) : initialProfile;
  });

  const [subjects, setSubjects] = useState<Subject[]>(() => {
    const saved = localStorage.getItem('studypilot_subjects');
    return saved ? JSON.parse(saved) : initialSubjects;
  });

  const [exams, setExams] = useState<Exam[]>(() => {
    const saved = localStorage.getItem('studypilot_exams');
    return saved ? JSON.parse(saved) : initialExams;
  });

  const [tasks, setTasks] = useState<Task[]>(() => {
    const saved = localStorage.getItem('studypilot_tasks');
    return saved ? JSON.parse(saved) : initialTasks;
  });

  const [sessions, setSessions] = useState<StudySession[]>(() => {
    const saved = localStorage.getItem('studypilot_sessions');
    return saved ? JSON.parse(saved) : initialSessions;
  });

  const [achievements, setAchievements] = useState<AchievementBadge[]>(() => {
    const saved = localStorage.getItem('studypilot_achievements');
    return saved ? JSON.parse(saved) : initialAchievements;
  });

  const [notifications, setNotifications] = useState<NotificationItem[]>(() => {
    const saved = localStorage.getItem('studypilot_notifications');
    return saved ? JSON.parse(saved) : initialNotifications;
  });

  const [activeRescheduleEvent, setActiveRescheduleEvent] = useState<AdaptiveRescheduleEvent | null>(() => {
    const saved = localStorage.getItem('studypilot_reschedule_alert');
    return saved ? JSON.parse(saved) : null;
  });

  const [activeFocusTaskId, setActiveFocusTaskId] = useState<string | null>(null);
  const [currentView, setCurrentView] = useState<string>('dashboard');
  const [theme, setTheme] = useState<'dark' | 'light'>('dark');

  // Persistence & Backend Synchronization
  useEffect(() => {
    // Initial fetch from backend REST API
    fetch('/api/data')
      .then((res) => {
        if (res.ok) return res.json();
        throw new Error('Backend not ready');
      })
      .then((data) => {
        if (data.profile) setProfile((p) => ({ ...p, ...data.profile }));
        if (data.subjects && data.subjects.length > 0) setSubjects(data.subjects);
        if (data.exams && data.exams.length > 0) setExams(data.exams);
        if (data.tasks && data.tasks.length > 0) setTasks(data.tasks);
        if (data.sessions && data.sessions.length > 0) setSessions(data.sessions);
      })
      .catch((err) => {
        console.info('Using local client state (backend sync ready):', err?.message || err);
      });
  }, []);

  useEffect(() => {
    localStorage.setItem('studypilot_profile', JSON.stringify(profile));
    fetch('/api/profile', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(profile),
    }).catch(() => {});
  }, [profile]);

  useEffect(() => {
    localStorage.setItem('studypilot_subjects', JSON.stringify(subjects));
  }, [subjects]);

  useEffect(() => {
    localStorage.setItem('studypilot_exams', JSON.stringify(exams));
  }, [exams]);

  useEffect(() => {
    localStorage.setItem('studypilot_tasks', JSON.stringify(tasks));
  }, [tasks]);

  useEffect(() => {
    localStorage.setItem('studypilot_sessions', JSON.stringify(sessions));
  }, [sessions]);

  useEffect(() => {
    localStorage.setItem('studypilot_notifications', JSON.stringify(notifications));
  }, [notifications]);

  useEffect(() => {
    if (activeRescheduleEvent) {
      localStorage.setItem('studypilot_reschedule_alert', JSON.stringify(activeRescheduleEvent));
    } else {
      localStorage.removeItem('studypilot_reschedule_alert');
    }
  }, [activeRescheduleEvent]);

  // Recalculate exam remaining days dynamically
  useEffect(() => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    setExams((prev) =>
      prev.map((exam) => {
        const ed = new Date(exam.examDate);
        ed.setHours(0, 0, 0, 0);
        const days = Math.max(0, Math.ceil((ed.getTime() - today.getTime()) / (1000 * 60 * 60 * 24)));
        return { ...exam, daysRemaining: days };
      })
    );
  }, []);

  const toggleTheme = () => {
    setTheme((prev) => (prev === 'dark' ? 'light' : 'dark'));
  };

  const updateProfile = (updated: Partial<StudentProfile>) => {
    setProfile((prev) => ({ ...prev, ...updated }));
  };

  const setEnergyMode = (mode: EnergyLevel) => {
    setProfile((prev) => {
      const updated = { ...prev, currentEnergy: mode };
      // Regenerate smart schedule when energy mode changes
      setTimeout(() => regenerateSchedule(), 50);
      return updated;
    });
  };

  const setTimeBudget = (hours: number | null) => {
    setProfile((prev) => {
      const updated = { ...prev, quickTimeBudget: hours };
      setTimeout(() => regenerateSchedule(), 50);
      return updated;
    });
  };

  const completeOnboarding = (data: Partial<StudentProfile>, newSubjects?: Subject[], newExams?: Exam[]) => {
    setProfile((prev) => ({
      ...prev,
      ...data,
      onboardingCompleted: true,
    }));
    if (newSubjects && newSubjects.length > 0) setSubjects(newSubjects);
    if (newExams && newExams.length > 0) setExams(newExams);
    setCurrentView('dashboard');
  };

  const resetToDemoData = () => {
    fetch('/api/reset-demo', { method: 'POST' }).catch(() => {});
    setProfile(initialProfile);
    setSubjects(initialSubjects);
    setExams(initialExams);
    setTasks(initialTasks);
    setSessions(initialSessions);
    setAchievements(initialAchievements);
    setNotifications(initialNotifications);
    setActiveRescheduleEvent(null);
    setCurrentView('dashboard');
  };

  const addTask = (taskData: Omit<Task, 'id' | 'calculatedPriority' | 'priorityScore' | 'priorityReason'>): Task => {
    const id = `task-${Date.now()}`;
    const subject = subjects.find((s) => s.id === taskData.subjectId);
    const subName = subject ? subject.name : taskData.subjectName;

    const { priority, score, reason } = calculateTaskPriority(
      {
        deadline: taskData.deadline,
        difficulty: taskData.difficulty,
        importance: taskData.importance,
        estimatedMinutes: taskData.estimatedMinutes,
        subjectId: taskData.subjectId,
      },
      subjects,
      exams
    );

    const newTask: Task = {
      ...taskData,
      id,
      subjectName: subName,
      calculatedPriority: priority,
      priorityScore: score,
      priorityReason: reason,
    };

    setTasks((prev) => [newTask, ...prev]);

    // Give points for planning
    setProfile((prev) => ({ ...prev, studyPoints: prev.studyPoints + 15 }));

    addNotification({
      title: 'Task Created & Scheduled',
      message: `"${newTask.title}" added with ${priority.toUpperCase()} priority.`,
      type: 'info',
      actionText: 'View Planner',
      actionRoute: 'planner',
    });

    fetch('/api/tasks', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(newTask),
    }).catch(() => {});

    return newTask;
  };

  const updateTask = (taskId: string, updates: Partial<Task>) => {
    fetch(`/api/tasks/${taskId}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(updates),
    }).catch(() => {});

    setTasks((prev) =>
      prev.map((t) => {
        if (t.id !== taskId) return t;
        const merged = { ...t, ...updates };
        const { priority, score, reason } = calculateTaskPriority(merged, subjects, exams);
        return {
          ...merged,
          calculatedPriority: priority,
          priorityScore: score,
          priorityReason: reason,
        };
      })
    );
  };

  const deleteTask = (taskId: string) => {
    fetch(`/api/tasks/${taskId}`, { method: 'DELETE' }).catch(() => {});
    setTasks((prev) => prev.filter((t) => t.id !== taskId));
    setSessions((prev) => prev.filter((s) => s.taskId !== taskId));
  };

  const toggleSubtask = (taskId: string, subtaskId: string) => {
    setTasks((prev) =>
      prev.map((t) => {
        if (t.id !== taskId) return t;
        const newSubtasks = t.subtasks.map((st) => (st.id === subtaskId ? { ...st, completed: !st.completed } : st));
        const completedCount = newSubtasks.filter((s) => s.completed).length;
        const progress = Math.round((completedCount / (newSubtasks.length || 1)) * 100);
        return {
          ...t,
          subtasks: newSubtasks,
          progressPercent: progress,
          status: progress === 100 ? 'completed' : progress > 0 ? 'in_progress' : t.status,
        };
      })
    );
  };

  const addSubtask = (taskId: string, title: string, estimatedMinutes: number = 20) => {
    setTasks((prev) =>
      prev.map((t) => {
        if (t.id !== taskId) return t;
        const newSub: any = {
          id: `st-${Date.now()}`,
          title,
          completed: false,
          estimatedMinutes,
        };
        const updatedSubs = [...t.subtasks, newSub];
        return {
          ...t,
          subtasks: updatedSubs,
          progressPercent: Math.round((updatedSubs.filter((s) => s.completed).length / updatedSubs.length) * 100),
        };
      })
    );
  };

  // Adaptive Rescheduling Trigger
  const markTaskStatus = (taskId: string, status: TaskStatus, remainingMins?: number) => {
    const targetTask = tasks.find((t) => t.id === taskId);
    if (!targetTask) return;

    if (status === 'completed') {
      setTasks((prev) =>
        prev.map((t) =>
          t.id === taskId
            ? {
                ...t,
                status: 'completed',
                progressPercent: 100,
                subtasks: t.subtasks.map((st) => ({ ...st, completed: true })),
              }
            : t
        )
      );

      // Reward points!
      setProfile((prev) => ({
        ...prev,
        studyPoints: prev.studyPoints + 50,
      }));

      addNotification({
        title: 'Task Completed! +50 XP 🚀',
        message: `Great job finishing "${targetTask.title}". Keep up your study streak!`,
        type: 'achievement',
      });
      return;
    }

    if (status === 'missed' || status === 'partially_completed') {
      const updatedEstimated = remainingMins || Math.max(25, Math.round(targetTask.estimatedMinutes * 0.6));

      setTasks((prev) =>
        prev.map((t) =>
          t.id === taskId
            ? {
                ...t,
                status,
                estimatedMinutes: updatedEstimated,
                progressPercent: status === 'partially_completed' ? 50 : t.progressPercent,
              }
            : t
        )
      );

      // Trigger automatic adaptive reschedule proposal!
      const proposal = createAdaptiveRescheduleProposal(targetTask, sessions, profile);
      setActiveRescheduleEvent(proposal);

      addNotification({
        title: 'Adaptive Schedule Generated',
        message: proposal.message,
        type: 'reschedule',
        actionText: 'Review Schedule',
        actionRoute: 'planner',
      });
    }
  };

  const acceptRescheduleProposal = (proposalId: string) => {
    if (!activeRescheduleEvent) return;

    // Shift sessions to apply the new slot
    setSessions((prev) => {
      return prev.map((s) => {
        if (s.taskId === activeRescheduleEvent.missedTaskId) {
          return {
            ...s,
            timeSlotString: activeRescheduleEvent.newSlot.replace('Today ', ''),
            isRescheduled: true,
            rescheduleReason: activeRescheduleEvent.reason,
          };
        }
        return s;
      });
    });

    addNotification({
      title: 'Schedule Updated Successfully',
      message: `Your revised study slots have been locked in. Balanced study plan restored.`,
      type: 'info',
    });

    setActiveRescheduleEvent(null);
  };

  const dismissRescheduleProposal = () => {
    setActiveRescheduleEvent(null);
  };

  const regenerateSchedule = (targetDate = getTodayDateString(0)) => {
    const newSessions = generateSmartSchedule({
      tasks,
      subjects,
      exams,
      profile,
      targetDate,
    });
    setSessions(newSessions);
  };

  const addSubject = (subjectData: Omit<Subject, 'id'>) => {
    const newSub: Subject = {
      ...subjectData,
      id: `sub-${Date.now()}`,
    };
    setSubjects((prev) => [...prev, newSub]);
  };

  const updateSubject = (id: string, updates: Partial<Subject>) => {
    setSubjects((prev) => prev.map((s) => (s.id === id ? { ...s, ...updates } : s)));
  };

  const deleteSubject = (id: string) => {
    setSubjects((prev) => prev.filter((s) => s.id !== id));
  };

  const addExam = (examData: Omit<Exam, 'id' | 'daysRemaining'>) => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const ed = new Date(examData.examDate);
    ed.setHours(0, 0, 0, 0);
    const days = Math.max(0, Math.ceil((ed.getTime() - today.getTime()) / (1000 * 60 * 60 * 24)));

    const newExam: Exam = {
      ...examData,
      id: `exam-${Date.now()}`,
      daysRemaining: days,
    };
    setExams((prev) => [...prev, newExam]);
  };

  const updateExam = (id: string, updates: Partial<Exam>) => {
    setExams((prev) => prev.map((e) => (e.id === id ? { ...e, ...updates } : e)));
  };

  const toggleExamRescueMode = (examId: string) => {
    setExams((prev) =>
      prev.map((e) => {
        if (e.id !== examId) return e;
        const nextState = !e.rescueModeActive;
        if (nextState) {
          addNotification({
            title: `🚨 Rescue Mode: ${e.title}`,
            message: `Emergency high-impact timetable generated. Core topics prioritized.`,
            type: 'urgent',
            actionText: 'View Exam Plan',
            actionRoute: 'exams',
          });
        }
        return { ...e, rescueModeActive: nextState };
      })
    );
  };

  const startFocusMode = (taskId?: string) => {
    if (taskId) {
      setActiveFocusTaskId(taskId);
    } else {
      const topTask = tasks.find((t) => t.status !== 'completed');
      setActiveFocusTaskId(topTask ? topTask.id : null);
    }
    setCurrentView('focus');
  };

  const exitFocusMode = () => {
    setActiveFocusTaskId(null);
  };

  const addNotification = (notif: Omit<NotificationItem, 'id' | 'timestamp' | 'read'>) => {
    const newNotif: NotificationItem = {
      ...notif,
      id: `notif-${Date.now()}`,
      timestamp: 'Just now',
      read: false,
    };
    setNotifications((prev) => [newNotif, ...prev]);
  };

  const markNotificationRead = (id: string) => {
    setNotifications((prev) => prev.map((n) => (n.id === id ? { ...n, read: true } : n)));
  };

  const clearNotifications = () => {
    setNotifications([]);
  };

  // AI Services Integration
  const getWhatShouldIStudyNow = async (): Promise<RecommendationResult> => {
    const weakSubjects = subjects.filter((s) => s.isWeakSubject || s.confidenceScore < 60);

    try {
      const response = await fetch('/api/ai/recommend-now', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          currentEnergy: profile.currentEnergy,
          availableHoursToday: profile.quickTimeBudget || profile.dailyAvailableHours,
          tasks: tasks.filter((t) => t.status !== 'completed'),
          exams,
          weakSubjects,
        }),
      });

      if (response.ok) {
        const data = await response.json();
        return data;
      }
    } catch (e) {
      console.warn('API recommend fallback to local engine:', e);
    }

    // Local heuristic backup
    const pending = tasks.filter((t) => t.status !== 'completed');
    const critical = pending.find((t) => t.calculatedPriority === 'critical') || pending[0];

    return {
      taskId: critical?.id,
      recommendedTask: critical ? critical.title : 'Review DBMS Normalization & SQL Queries',
      subject: critical ? critical.subjectName : 'DBMS',
      suggestedMinutes: profile.currentEnergy === 'low' ? 25 : critical?.estimatedMinutes || 45,
      priorityLevel: critical?.calculatedPriority || 'critical',
      reason: critical
        ? critical.priorityReason
        : 'High Priority — Exam in 4 days + marked as weak topic + high exam weight.',
      firstStep: 'Open slide 4 of Chapter 3 and solve the first 3NF functional dependency exercise.',
      energyFit: profile.currentEnergy === 'high' ? 'High energy matched for deep problem solving' : 'Paced for low energy',
    };
  };

  const requestTaskBreakdown = async (title: string, subject?: string, hours?: number, notes?: string) => {
    try {
      const response = await fetch('/api/ai/breakdown', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ title, subject, estimatedHours: hours, notes }),
      });
      if (response.ok) {
        return await response.json();
      }
    } catch (e) {
      console.warn('AI breakdown fallback:', e);
    }

    return {
      subtasks: [
        { title: `Foundational Review: ${title}`, estimatedMinutes: 40, priority: 'high', difficulty: 'medium' },
        { title: `Core Problem Solving & Exercise Practice`, estimatedMinutes: 50, priority: 'critical', difficulty: 'hard' },
        { title: `Summary Sheet & Formula Verification`, estimatedMinutes: 30, priority: 'medium', difficulty: 'easy' },
        { title: `Past Exam / Quiz Question Check`, estimatedMinutes: 40, priority: 'high', difficulty: 'medium' },
      ],
      studyTip: 'Break complex topics into 25-minute Pomodoro bursts. Active retrieval beats passive reading by 300%.',
    };
  };

  const requestExamRescue = async (exam: Exam, dailyHours = 4) => {
    try {
      const response = await fetch('/api/ai/exam-rescue', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          examSubject: exam.subjectName,
          daysRemaining: exam.daysRemaining,
          syllabusOrTopics: exam.syllabusTopics.join(', '),
          dailyHours,
        }),
      });
      if (response.ok) {
        return await response.json();
      }
    } catch (e) {
      console.warn('Exam rescue API fallback:', e);
    }

    return {
      rescuePlan: [
        {
          day: 'Day 1',
          focusTheme: 'Core High-Yield Concepts & Definitions',
          sessions: [
            { timeSlot: '09:00 AM - 10:15 AM', topic: `${exam.subjectName} Unit 1 Foundations`, technique: 'Active Recall', durationMinutes: 75 },
            { timeSlot: '11:00 AM - 12:15 PM', topic: `${exam.subjectName} High-Weight Questions`, technique: 'Past Papers', durationMinutes: 75 },
            { timeSlot: '04:30 PM - 05:45 PM', topic: 'Weak Areas Intensive Drill', technique: 'Feynman Technique', durationMinutes: 75 },
          ],
        },
        {
          day: 'Day 2',
          focusTheme: 'Complex Problems & Mock Examination',
          sessions: [
            { timeSlot: '09:00 AM - 10:30 AM', topic: 'Advanced Practical Problems', technique: 'Timed Drills', durationMinutes: 90 },
            { timeSlot: '02:00 PM - 03:15 PM', topic: 'Mock Test Paper (45 mins) + Correction', technique: 'Simulation', durationMinutes: 75 },
            { timeSlot: '06:00 PM - 07:00 PM', topic: 'Formula & Diagram Revision Sheet', technique: 'Spaced Repetition', durationMinutes: 60 },
          ],
        },
      ],
      emergencyAdvice: '1. Prioritize scoring questions first. 2. Sleep at least 7 hours before the exam. 3. Stop studying new topics 4 hours before the exam.',
      highYieldChecklist: [
        'Top 5 most frequent 10-mark long questions',
        'All standard architectural diagrams & schemas',
        'Key definitions and edge cases',
        'Formula / shortcut cheat sheet memorized',
      ],
    };
  };

  return (
    <AppContext.Provider
      value={{
        profile,
        subjects,
        exams,
        tasks,
        sessions,
        achievements,
        notifications,
        activeRescheduleEvent,
        activeFocusTaskId,
        currentView,
        theme,
        setCurrentView,
        toggleTheme,
        updateProfile,
        setEnergyMode,
        setTimeBudget,
        completeOnboarding,
        resetToDemoData,
        addTask,
        updateTask,
        deleteTask,
        toggleSubtask,
        addSubtask,
        markTaskStatus,
        addSubject,
        updateSubject,
        deleteSubject,
        addExam,
        updateExam,
        toggleExamRescueMode,
        regenerateSchedule,
        acceptRescheduleProposal,
        dismissRescheduleProposal,
        startFocusMode,
        exitFocusMode,
        getWhatShouldIStudyNow,
        requestTaskBreakdown,
        requestExamRescue,
        markNotificationRead,
        clearNotifications,
        addNotification,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) throw new Error('useApp must be used within AppProvider');
  return context;
};
