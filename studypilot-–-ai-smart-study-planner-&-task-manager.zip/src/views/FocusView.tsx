import React, { useState, useEffect, useRef } from 'react';
import {
  Timer,
  Play,
  Pause,
  RotateCcw,
  CheckCircle2,
  Coffee,
  Volume2,
  VolumeX,
  Sparkles,
  Flame,
  ArrowLeft,
  AlertCircle,
} from 'lucide-react';
import { useApp } from '../context/AppContext';

export const FocusView: React.FC = () => {
  const {
    tasks,
    activeFocusTaskId,
    startFocusMode,
    exitFocusMode,
    markTaskStatus,
    setCurrentView,
    profile,
  } = useApp();

  // Find active task or default to first pending
  const activeTask = tasks.find((t) => t.id === activeFocusTaskId) || tasks.find((t) => t.status !== 'completed');

  // Pomodoro timer state
  const [sessionMinutes, setSessionMinutes] = useState(25);
  const [timeLeftSeconds, setTimeLeftSeconds] = useState(25 * 60);
  const [isRunning, setIsRunning] = useState(false);
  const [isBreak, setIsBreak] = useState(false);
  const [roundsCompleted, setRoundsCompleted] = useState(0);
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [showCompletionModal, setShowCompletionModal] = useState(false);
  const [partialRemainingMins, setPartialRemainingMins] = useState(20);

  const timerRef = useRef<any>(null);

  useEffect(() => {
    if (isRunning) {
      timerRef.current = setInterval(() => {
        setTimeLeftSeconds((prev) => {
          if (prev <= 1) {
            clearInterval(timerRef.current);
            setIsRunning(false);
            handleSessionFinished();
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    } else {
      if (timerRef.current) clearInterval(timerRef.current);
    }

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [isRunning, isBreak]);

  const handleSessionFinished = () => {
    if (!isBreak) {
      setRoundsCompleted((prev) => prev + 1);
      setShowCompletionModal(true);
    } else {
      setIsBreak(false);
      setTimeLeftSeconds(sessionMinutes * 60);
    }
  };

  const handleSelectMinutes = (mins: number) => {
    setIsRunning(false);
    setSessionMinutes(mins);
    setTimeLeftSeconds(mins * 60);
    setIsBreak(false);
  };

  const handleReset = () => {
    setIsRunning(false);
    setTimeLeftSeconds(sessionMinutes * 60);
    setIsBreak(false);
  };

  const minutesDisplay = Math.floor(timeLeftSeconds / 60);
  const secondsDisplay = timeLeftSeconds % 60;
  const progressPercent = Math.round(
    (((sessionMinutes * 60) - timeLeftSeconds) / (sessionMinutes * 60)) * 100
  );

  const motivationalQuotes = [
    '“Success is the sum of small efforts, repeated day in and day out.”',
    '“Deep focus produces results in 25 minutes that distraction cannot in 3 hours.”',
    '“Your future college GPA is made right here in this session.”',
    '“Action eliminates fear. One problem at a time.”',
  ];
  const activeQuote = motivationalQuotes[roundsCompleted % motivationalQuotes.length];

  return (
    <div className="max-w-2xl mx-auto space-y-6 pb-12">
      {/* Top Bar */}
      <div className="flex items-center justify-between">
        <button
          onClick={() => setCurrentView('dashboard')}
          className="text-xs text-slate-400 hover:text-white flex items-center gap-1.5 transition-colors cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Exit to Dashboard</span>
        </button>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setSoundEnabled(!soundEnabled)}
            className="p-2 rounded-xl bg-slate-900 border border-slate-800 text-slate-400 hover:text-white transition-colors"
            title="Audio alerts"
          >
            {soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
          </button>
          <span className="px-3 py-1 rounded-xl bg-slate-900 border border-slate-800 text-xs font-semibold text-amber-400 flex items-center gap-1">
            <Flame className="w-3.5 h-3.5 fill-amber-400" />
            <span>Rounds: {roundsCompleted}</span>
          </span>
        </div>
      </div>

      {/* Main Focus Card */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-b from-slate-900 to-slate-950 border border-indigo-500/30 p-6 sm:p-10 text-center shadow-2xl shadow-indigo-500/10 space-y-6">
        {/* Glow orb */}
        <div className="absolute -top-32 left-1/2 -translate-x-1/2 w-64 h-64 bg-indigo-500/15 rounded-full blur-3xl pointer-events-none" />

        {/* Current Task Display & Selector */}
        <div className="space-y-2 relative z-10">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-indigo-500/10 text-indigo-300 border border-indigo-500/20 text-xs font-semibold">
            <Sparkles className="w-3 h-3 text-amber-300" />
            <span>Current Focus Task</span>
          </div>

          {activeTask ? (
            <div>
              <h2 className="text-lg sm:text-2xl font-black text-white max-w-lg mx-auto">
                {activeTask.title}
              </h2>
              <p className="text-xs text-slate-400 mt-1">
                {activeTask.subjectName} • Due: {activeTask.deadline} • {activeTask.priorityReason}
              </p>
            </div>
          ) : (
            <p className="text-sm text-slate-400">No active task selected.</p>
          )}

          {/* Quick Task Switcher Dropdown */}
          <div className="pt-1">
            <select
              value={activeTask?.id || ''}
              onChange={(e) => startFocusMode(e.target.value)}
              className="px-3 py-1 rounded-lg bg-slate-950 border border-slate-800 text-xs text-slate-300 focus:border-indigo-500 cursor-pointer"
            >
              {tasks.filter((t) => t.status !== 'completed').map((t) => (
                <option key={t.id} value={t.id}>
                  Switch to: {t.title} ({t.subjectName})
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Big Circular Countdown Display */}
        <div className="relative z-10 py-4 flex flex-col items-center justify-center">
          <div className="w-60 h-60 sm:w-68 sm:h-68 rounded-full border-4 border-slate-800 flex flex-col items-center justify-center relative shadow-inner bg-slate-950/60">
            {/* Circular progress highlight ring */}
            <svg className="absolute inset-0 w-full h-full -rotate-90">
              <circle
                cx="50%"
                cy="50%"
                r="46%"
                className="fill-none stroke-indigo-500/80 transition-all duration-1000"
                strokeWidth="4"
                strokeDasharray="290"
                strokeDashoffset={290 - (290 * progressPercent) / 100}
              />
            </svg>

            <div className="font-mono text-5xl sm:text-6xl font-black text-white tracking-tight">
              {String(minutesDisplay).padStart(2, '0')}:{String(secondsDisplay).padStart(2, '0')}
            </div>

            <span className="text-xs uppercase font-bold tracking-widest text-slate-400 mt-2">
              {isBreak ? 'Resting Break' : isRunning ? 'Deep Focus' : 'Paused'}
            </span>
          </div>
        </div>

        {/* Duration Selectors */}
        <div className="flex items-center justify-center gap-2 relative z-10">
          {[25, 45, 50].map((mins) => (
            <button
              key={mins}
              onClick={() => handleSelectMinutes(mins)}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all ${
                sessionMinutes === mins && !isBreak
                  ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
                  : 'bg-slate-950 border border-slate-800 text-slate-400 hover:text-white'
              }`}
            >
              {mins}m Work
            </button>
          ))}
          <button
            onClick={() => {
              setIsRunning(false);
              setIsBreak(true);
              setSessionMinutes(5);
              setTimeLeftSeconds(5 * 60);
            }}
            className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all flex items-center gap-1 ${
              isBreak
                ? 'bg-emerald-600 text-white'
                : 'bg-slate-950 border border-slate-800 text-emerald-400 hover:bg-slate-900'
            }`}
          >
            <Coffee className="w-3.5 h-3.5" />
            <span>5m Break</span>
          </button>
        </div>

        {/* Action Controls */}
        <div className="flex items-center justify-center gap-3 relative z-10 pt-2">
          <button
            onClick={() => setIsRunning(!isRunning)}
            className="px-8 py-3.5 rounded-2xl bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-500 hover:to-violet-500 text-white font-bold text-sm shadow-xl shadow-indigo-600/40 hover:scale-[1.03] active:scale-[0.98] transition-all flex items-center gap-2 cursor-pointer"
          >
            {isRunning ? (
              <>
                <Pause className="w-5 h-5 fill-white" />
                <span>Pause</span>
              </>
            ) : (
              <>
                <Play className="w-5 h-5 fill-white" />
                <span>{timeLeftSeconds < sessionMinutes * 60 ? 'Resume' : 'Start Focus'}</span>
              </>
            )}
          </button>

          <button
            onClick={handleReset}
            className="p-3.5 rounded-2xl bg-slate-950 border border-slate-800 hover:border-slate-700 text-slate-400 hover:text-white transition-colors cursor-pointer"
            title="Reset timer"
          >
            <RotateCcw className="w-5 h-5" />
          </button>

          <button
            onClick={() => setShowCompletionModal(true)}
            className="px-4 py-3.5 rounded-2xl bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-300 border border-emerald-500/30 font-semibold text-xs flex items-center gap-1.5 cursor-pointer"
            title="Finish session early"
          >
            <CheckCircle2 className="w-4 h-4" />
            <span>Finish Task</span>
          </button>
        </div>

        {/* Motivational Banner */}
        <p className="text-xs text-slate-400 italic pt-2 max-w-md mx-auto">
          {activeQuote}
        </p>
      </div>

      {/* Post-Session Reflection Modal (Requirement 6) */}
      {showCompletionModal && activeTask && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
          <div className="relative w-full max-w-md rounded-2xl bg-slate-900 border border-indigo-500/40 p-6 shadow-2xl space-y-4">
            <div className="text-center space-y-1">
              <div className="w-12 h-12 rounded-2xl bg-indigo-500/20 text-indigo-400 flex items-center justify-center mx-auto mb-2">
                <CheckCircle2 className="w-6 h-6" />
              </div>
              <h3 className="font-bold text-lg text-white">
                Session Completed!
              </h3>
              <p className="text-xs text-slate-400">
                Did you complete <strong className="text-white">&quot;{activeTask.title}&quot;</strong>?
              </p>
            </div>

            <div className="space-y-2 pt-2">
              <button
                onClick={() => {
                  markTaskStatus(activeTask.id, 'completed');
                  setShowCompletionModal(false);
                  exitFocusMode();
                  setCurrentView('dashboard');
                }}
                className="w-full py-2.5 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs flex items-center justify-center gap-2 cursor-pointer shadow-md shadow-emerald-600/20"
              >
                <span>✅ Fully Completed (+50 XP)</span>
              </button>

              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
                <button
                  onClick={() => {
                    markTaskStatus(activeTask.id, 'partially_completed', partialRemainingMins);
                    setShowCompletionModal(false);
                    exitFocusMode();
                    setCurrentView('dashboard');
                  }}
                  className="w-full py-2 px-3 rounded-lg bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/30 font-semibold text-xs flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <span>🔄 Partially Completed (Auto-Reschedule Remaining)</span>
                </button>
                <div className="flex items-center justify-between text-[11px] text-slate-400">
                  <span>Remaining time needed:</span>
                  <div className="flex items-center gap-1 font-mono">
                    <input
                      type="number"
                      min="10"
                      max="120"
                      value={partialRemainingMins}
                      onChange={(e) => setPartialRemainingMins(Number(e.target.value))}
                      className="w-14 px-1.5 py-0.5 rounded bg-slate-900 border border-slate-700 text-center text-white text-xs"
                    />
                    <span>mins</span>
                  </div>
                </div>
              </div>

              <button
                onClick={() => {
                  markTaskStatus(activeTask.id, 'missed');
                  setShowCompletionModal(false);
                  exitFocusMode();
                  setCurrentView('dashboard');
                }}
                className="w-full py-2 px-4 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 text-rose-300 border border-rose-500/30 font-medium text-xs flex items-center justify-center gap-2 cursor-pointer"
              >
                <span>❌ Not Completed (Move to Next Open Slot)</span>
              </button>
            </div>

            <p className="text-[11px] text-center text-slate-500">
              StudyPilot uses your answer to auto-reorganize your remaining study plan without shame.
            </p>
          </div>
        </div>
      )}
    </div>
  );
};
