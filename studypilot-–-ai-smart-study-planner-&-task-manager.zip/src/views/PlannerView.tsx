import React, { useState } from 'react';
import {
  CalendarDays,
  Sparkles,
  Clock,
  Zap,
  Play,
  RotateCcw,
  CheckCircle2,
  Calendar,
  Layers,
  Flame,
  Info,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { AdaptiveRescheduleBanner } from '../components/AdaptiveRescheduleBanner';
import { EnergyLevel } from '../types';

export const PlannerView: React.FC<{ onOpenWhatToStudy: () => void }> = ({ onOpenWhatToStudy }) => {
  const {
    sessions,
    profile,
    setEnergyMode,
    setTimeBudget,
    regenerateSchedule,
    startFocusMode,
    activeRescheduleEvent,
  } = useApp();

  const [activeTab, setActiveTab] = useState<'today' | 'week'>('today');

  const energyOptions: { level: EnergyLevel; label: string; icon: string; desc: string }[] = [
    { level: 'high', label: 'High Energy', icon: '⚡', desc: 'Schedules complex coding, heavy math & difficult exam topics' },
    { level: 'normal', label: 'Normal Energy', icon: '⚖️', desc: 'Balanced distribution of standard homework & lecture review' },
    { level: 'low', label: 'Low Energy', icon: '🌙', desc: 'Recommends easier tasks, flashcards, short practice & quick readings' },
  ];

  return (
    <div className="space-y-6 pb-12">
      {/* 1. Adaptive Reschedule Banner */}
      <AdaptiveRescheduleBanner />

      {/* 2. Top Header & Energy Controls */}
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-bold text-white flex items-center gap-2">
            <CalendarDays className="w-6 h-6 text-indigo-400" />
            AI Smart Study Planner &amp; Schedule
          </h2>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Intelligently distributes your assignments across available study sessions instead of sorting by date
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => regenerateSchedule()}
            className="px-3.5 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-200 text-xs font-medium flex items-center gap-1.5 transition-colors cursor-pointer"
            title="Recalculate slots with current parameters"
          >
            <RotateCcw className="w-3.5 h-3.5 text-indigo-400" />
            <span>Re-balance Schedule</span>
          </button>
          <button
            onClick={onOpenWhatToStudy}
            className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs flex items-center gap-1.5 shadow-md shadow-indigo-600/30 cursor-pointer"
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-300" />
            <span>Study Now?</span>
          </button>
        </div>
      </div>

      {/* 3. Innovative Controls: Energy Mode & Time-Aware Planning */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Study Energy Mode (Requirement 12) */}
        <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-300 flex items-center gap-2">
              <Zap className="w-4 h-4 text-amber-400" />
              Study Energy Mode
            </h3>
            <span className="text-[10px] bg-slate-800 text-slate-400 px-2 py-0.5 rounded-full font-mono">
              Current: {profile.currentEnergy.toUpperCase()}
            </span>
          </div>

          <div className="grid grid-cols-3 gap-2">
            {energyOptions.map((opt) => (
              <button
                key={opt.level}
                onClick={() => setEnergyMode(opt.level)}
                className={`p-2.5 rounded-xl border text-left transition-all ${
                  profile.currentEnergy === opt.level
                    ? 'bg-indigo-600/20 border-indigo-500/50 shadow-sm'
                    : 'bg-slate-950/60 border-slate-800 hover:border-slate-700 text-slate-400'
                }`}
              >
                <div className="text-sm">{opt.icon}</div>
                <div className="text-xs font-bold text-white mt-1">{opt.label}</div>
              </button>
            ))}
          </div>
          <p className="text-[11px] text-slate-400">
            {energyOptions.find((e) => e.level === profile.currentEnergy)?.desc}
          </p>
        </div>

        {/* Time-Aware Planning: "I have only X hours today" (Requirement 13) */}
        <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-300 flex items-center gap-2">
              <Clock className="w-4 h-4 text-indigo-400" />
              Time-Aware Planning Filter
            </h3>
            <span className="text-[10px] text-indigo-300 bg-indigo-500/10 px-2 py-0.5 rounded-full border border-indigo-500/20">
              {profile.quickTimeBudget ? `${profile.quickTimeBudget}h Budget` : `Default ${profile.dailyAvailableHours}h`}
            </span>
          </div>

          <p className="text-xs text-slate-400">
            Pressed for time today? Select how much time you actually have, and StudyPilot will curate the best high-yield plan.
          </p>

          <div className="flex flex-wrap items-center gap-2">
            {[1, 2, 3, 4].map((hours) => (
              <button
                key={hours}
                onClick={() => setTimeBudget(hours)}
                className={`px-3 py-1.5 rounded-xl text-xs font-medium border transition-colors ${
                  profile.quickTimeBudget === hours
                    ? 'bg-indigo-600 text-white border-indigo-500 font-bold'
                    : 'bg-slate-950 border-slate-800 text-slate-300 hover:border-slate-700'
                }`}
              >
                &quot;I have only {hours}h today&quot;
              </button>
            ))}
            {profile.quickTimeBudget && (
              <button
                onClick={() => setTimeBudget(null)}
                className="px-2.5 py-1.5 text-xs text-slate-400 hover:text-white"
              >
                Clear Budget
              </button>
            )}
          </div>
        </div>
      </div>

      {/* 4. Timeline Schedule View */}
      <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setActiveTab('today')}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold ${
                activeTab === 'today'
                  ? 'bg-indigo-600 text-white'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Today&apos;s Schedule
            </button>
            <button
              onClick={() => setActiveTab('week')}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold ${
                activeTab === 'week'
                  ? 'bg-indigo-600 text-white'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Weekly Distribution
            </button>
          </div>

          <span className="text-xs text-slate-400">
            Total Today: {sessions.reduce((acc, s) => acc + s.durationMinutes, 0)} mins
          </span>
        </div>

        {activeTab === 'today' ? (
          <div className="space-y-3 relative before:absolute before:inset-0 before:left-5 before:w-0.5 before:bg-slate-800/80">
            {sessions.map((sess, idx) => (
              <div
                key={sess.id}
                className="relative pl-10 sm:pl-12 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 p-3.5 rounded-xl bg-slate-950 border border-slate-800/90 hover:border-slate-700 transition-all"
              >
                {/* Timeline node */}
                <div
                  className="absolute left-3.5 top-5 -translate-x-1/2 w-4 h-4 rounded-full border-2 border-slate-900 shadow"
                  style={{ backgroundColor: sess.subjectColor }}
                />

                <div className="space-y-1">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="text-xs font-bold text-white font-mono">
                      {sess.timeSlotString}
                    </span>
                    <span className="text-[10px] font-semibold uppercase px-2 py-0.5 rounded-md bg-slate-900 text-slate-300 border border-slate-800">
                      {sess.subjectName}
                    </span>
                    <span className="text-[11px] text-slate-400 font-mono">
                      {sess.durationMinutes} mins
                    </span>
                    {sess.isRescheduled && (
                      <span className="text-[10px] font-bold px-1.5 py-0.2 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30">
                        Adaptive Shift
                      </span>
                    )}
                  </div>
                  <h4 className="text-sm font-semibold text-white">
                    {sess.taskTitle}
                  </h4>
                  {sess.rescheduleReason && (
                    <p className="text-[11px] text-amber-400/90">
                      ➜ {sess.rescheduleReason}
                    </p>
                  )}
                </div>

                <div className="flex items-center gap-2 shrink-0 w-full sm:w-auto justify-end">
                  <button
                    onClick={() => startFocusMode(sess.taskId)}
                    className="px-3.5 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-medium text-xs flex items-center gap-1.5 cursor-pointer shadow-sm shadow-indigo-600/30"
                  >
                    <Play className="w-3.5 h-3.5 fill-white" />
                    <span>Start Session</span>
                  </button>
                </div>
              </div>
            ))}

            {sessions.length === 0 && (
              <div className="py-12 text-center text-slate-400 text-xs pl-8">
                No sessions scheduled. Click &quot;Re-balance Schedule&quot; to populate.
              </div>
            )}
          </div>
        ) : (
          /* Weekly Distribution View */
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3">
            {['Monday (Today)', 'Tuesday', 'Wednesday', 'Thursday'].map((day, i) => (
              <div key={day} className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
                <div className="flex items-center justify-between pb-2 border-b border-slate-800">
                  <span className="font-bold text-white text-xs">{day}</span>
                  <span className="text-[10px] text-indigo-400 font-mono">
                    {i === 0 ? `${sessions.length} sessions` : `${3 - (i % 2)} sessions`}
                  </span>
                </div>
                <div className="space-y-1.5 text-xs">
                  {i === 0 ? (
                    sessions.map((s) => (
                      <div key={s.id} className="p-2 rounded-lg bg-slate-900 border border-slate-800/80">
                        <div className="font-semibold text-white truncate">{s.taskTitle}</div>
                        <div className="text-[10px] text-slate-400">{s.timeSlotString}</div>
                      </div>
                    ))
                  ) : (
                    <>
                      <div className="p-2 rounded-lg bg-slate-900 border border-slate-800/80">
                        <div className="font-semibold text-white">AI Search Algorithms Practice</div>
                        <div className="text-[10px] text-slate-400">05:30 PM - 06:15 PM</div>
                      </div>
                      <div className="p-2 rounded-lg bg-slate-900 border border-slate-800/80">
                        <div className="font-semibold text-white">Discrete Maths Spanning Trees</div>
                        <div className="text-[10px] text-slate-400">06:30 PM - 07:15 PM</div>
                      </div>
                    </>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
