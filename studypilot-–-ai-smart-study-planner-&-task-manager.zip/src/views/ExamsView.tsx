import React, { useState } from 'react';
import {
  GraduationCap,
  Calendar,
  Clock,
  ShieldAlert,
  Plus,
  BookOpen,
  Sparkles,
  CheckCircle2,
  AlertTriangle,
  Layers,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { Exam } from '../types';
import { getTodayDateString } from '../utils/demoData';
import { ExamRescueModal } from '../components/ExamRescueModal';

export const ExamsView: React.FC = () => {
  const { exams, subjects, addExam, toggleExamRescueMode } = useApp();

  const [selectedRescueExam, setSelectedRescueExam] = useState<Exam | null>(null);
  const [isAdding, setIsAdding] = useState(false);
  const [examTitle, setExamTitle] = useState('');
  const [examSubId, setExamSubId] = useState(subjects[0]?.id || '');
  const [examDate, setExamDate] = useState(getTodayDateString(7));
  const [examWeight, setExamWeight] = useState(30);
  const [estimatedHours, setEstimatedHours] = useState(12);

  const handleAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!examTitle.trim()) return;
    const sub = subjects.find((s) => s.id === examSubId) || subjects[0];

    addExam({
      title: examTitle.trim(),
      subjectId: sub.id,
      subjectName: sub.name,
      examDate,
      totalWeightage: examWeight,
      estimatedHoursNeeded: estimatedHours,
      preparedHours: 0,
      syllabusTopics: ['Core Theory & Definitions', 'Important Numerical Exercises', 'Previous Year Papers'],
      rescueModeActive: false,
    });

    setIsAdding(false);
    setExamTitle('');
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-bold text-white flex items-center gap-2">
            <GraduationCap className="w-6 h-6 text-rose-400" />
            Exams &amp; Exam Rescue Mode
          </h2>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Real-time countdowns, revision hour distribution, and emergency high-yield rescue plans
          </p>
        </div>

        <button
          onClick={() => setIsAdding(!isAdding)}
          className="px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs flex items-center gap-2 shadow-md shadow-indigo-600/30 cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>Add Upcoming Exam</span>
        </button>
      </div>

      {/* Add Exam Form */}
      {isAdding && (
        <form
          onSubmit={handleAddSubmit}
          className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-3.5"
        >
          <h3 className="font-bold text-sm text-white">Register Upcoming Exam</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            <div>
              <label className="block text-xs text-slate-400 mb-1">Exam Title</label>
              <input
                type="text"
                required
                placeholder="e.g. AI Theory End-Sem"
                value={examTitle}
                onChange={(e) => setExamTitle(e.target.value)}
                className="w-full px-3 py-1.5 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white"
              />
            </div>
            <div>
              <label className="block text-xs text-slate-400 mb-1">Subject</label>
              <select
                value={examSubId}
                onChange={(e) => setExamSubId(e.target.value)}
                className="w-full px-3 py-1.5 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white"
              >
                {subjects.map((sub) => (
                  <option key={sub.id} value={sub.id}>
                    {sub.name}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-xs text-slate-400 mb-1">Date</label>
              <input
                type="date"
                required
                value={examDate}
                onChange={(e) => setExamDate(e.target.value)}
                className="w-full px-3 py-1.5 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white"
              />
            </div>
            <div>
              <label className="block text-xs text-slate-400 mb-1">Est. Prep Hours Needed</label>
              <input
                type="number"
                min="2"
                max="50"
                value={estimatedHours}
                onChange={(e) => setEstimatedHours(Number(e.target.value))}
                className="w-full px-3 py-1.5 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white"
              />
            </div>
          </div>
          <div className="flex items-center justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => setIsAdding(false)}
              className="px-3 py-1.5 text-xs text-slate-400 hover:text-white"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-1.5 rounded-xl bg-indigo-600 text-white text-xs font-semibold"
            >
              Save Exam
            </button>
          </div>
        </form>
      )}

      {/* Exam Cards Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        {exams.map((exam) => {
          const isUrgent = exam.daysRemaining <= 5;
          const prepPercent = Math.min(100, Math.round((exam.preparedHours / exam.estimatedHoursNeeded) * 100));

          return (
            <div
              key={exam.id}
              className={`p-5 rounded-2xl border transition-all space-y-4 flex flex-col justify-between ${
                isUrgent
                  ? 'bg-gradient-to-b from-rose-950/40 to-slate-900 border-rose-500/40 shadow-lg shadow-rose-500/5'
                  : 'bg-slate-900/80 border-slate-800'
              }`}
            >
              <div className="space-y-3">
                {/* Countdown Badge */}
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-indigo-400">
                    {exam.subjectName}
                  </span>
                  <div
                    className={`font-mono font-bold text-xs px-2.5 py-1 rounded-lg ${
                      isUrgent
                        ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40 animate-pulse'
                        : 'bg-slate-800 text-slate-300'
                    }`}
                  >
                    ⏳ {exam.daysRemaining} days remaining
                  </div>
                </div>

                <h3 className="font-bold text-base text-white">
                  {exam.title}
                </h3>

                {/* Progress bar */}
                <div className="space-y-1 text-xs">
                  <div className="flex items-center justify-between text-slate-400">
                    <span>Preparation Readiness:</span>
                    <span className="font-bold text-white">{prepPercent}%</span>
                  </div>
                  <div className="w-full bg-slate-800 rounded-full h-2 overflow-hidden">
                    <div
                      className={`h-2 rounded-full transition-all ${
                        prepPercent >= 70 ? 'bg-emerald-500' : 'bg-indigo-500'
                      }`}
                      style={{ width: `${prepPercent}%` }}
                    />
                  </div>
                  <div className="flex items-center justify-between text-[11px] text-slate-500 pt-1">
                    <span>Completed: {exam.preparedHours}h</span>
                    <span>Total Needed: {exam.estimatedHoursNeeded}h</span>
                  </div>
                </div>

                {/* Syllabus Topics */}
                <div>
                  <h4 className="text-[11px] font-bold uppercase tracking-wider text-slate-400 mb-1.5 flex items-center gap-1">
                    <Layers className="w-3 h-3 text-indigo-400" /> High-Yield Syllabus Topics
                  </h4>
                  <div className="space-y-1">
                    {exam.syllabusTopics.slice(0, 3).map((topic, i) => (
                      <div
                        key={i}
                        className="text-[11px] text-slate-300 flex items-center gap-1.5"
                      >
                        <span className="text-indigo-400">•</span>
                        <span className="truncate">{topic}</span>
                      </div>
                    ))}
                    {exam.syllabusTopics.length > 3 && (
                      <span className="text-[10px] text-slate-500">
                        +{exam.syllabusTopics.length - 3} more topics in syllabus
                      </span>
                    )}
                  </div>
                </div>
              </div>

              {/* Exam Rescue Action */}
              <div className="pt-3 border-t border-slate-800/80 space-y-2">
                <button
                  onClick={() => setSelectedRescueExam(exam)}
                  className={`w-full py-2.5 px-3 rounded-xl font-semibold text-xs flex items-center justify-center gap-2 shadow-md transition-all cursor-pointer ${
                    exam.rescueModeActive
                      ? 'bg-rose-500 text-white shadow-rose-500/30'
                      : 'bg-gradient-to-r from-rose-600 to-indigo-600 hover:from-rose-500 hover:to-indigo-500 text-white shadow-rose-600/20'
                  }`}
                >
                  <ShieldAlert className="w-4 h-4" />
                  <span>
                    {exam.rescueModeActive ? 'Rescue Mode Active (View Plan)' : 'Activate Exam Rescue Mode'}
                  </span>
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Rescue Modal */}
      <ExamRescueModal
        exam={selectedRescueExam}
        isOpen={!!selectedRescueExam}
        onClose={() => setSelectedRescueExam(null)}
      />
    </div>
  );
};
