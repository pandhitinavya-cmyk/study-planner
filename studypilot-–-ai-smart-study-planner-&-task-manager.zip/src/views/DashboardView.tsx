import React from 'react';
import {
  Sparkles,
  Play,
  CheckCircle2,
  Clock,
  AlertTriangle,
  GraduationCap,
  Calendar,
  Flame,
  Zap,
  TrendingUp,
  BookOpen,
  ArrowRight,
  Plus,
  RefreshCw,
  ShieldAlert,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { AdaptiveRescheduleBanner } from '../components/AdaptiveRescheduleBanner';

interface DashboardViewProps {
  onOpenWhatToStudy: () => void;
  onOpenAddTask: () => void;
  onOpenAiBreakdown: () => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  onOpenWhatToStudy,
  onOpenAddTask,
  onOpenAiBreakdown,
}) => {
  const {
    profile,
    tasks,
    sessions,
    exams,
    subjects,
    setCurrentView,
    startFocusMode,
    markTaskStatus,
    setEnergyMode,
  } = useApp();

  const completedTasks = tasks.filter((t) => t.status === 'completed');
  const pendingTasks = tasks.filter((t) => t.status !== 'completed');
  const criticalTasks = pendingTasks.filter((t) => t.calculatedPriority === 'critical' || t.calculatedPriority === 'high');

  // Nearest exam
  const nearestExam = [...exams].sort((a, b) => a.daysRemaining - b.daysRemaining)[0];

  // Today's total scheduled minutes
  const totalScheduledMinutes = sessions.reduce((acc, s) => acc + s.durationMinutes, 0);
  const completedMinutes = sessions.filter((s) => s.isCompleted).reduce((acc, s) => acc + s.durationMinutes, 0);

  // Productivity score calculation
  const taskCompletionRate = tasks.length > 0 ? (completedTasks.length / tasks.length) * 100 : 80;
  const productivityScore = Math.min(100, Math.round(taskCompletionRate * 0.5 + (profile.streakDays * 5) + 35));

  // Weak subjects
  const weakSubjects = subjects.filter((s) => s.isWeakSubject || s.confidenceScore < 60);

  return (
    <div className="space-y-6 pb-12">
      {/* 1. Adaptive Rescheduling Alert (If active) */}
      <AdaptiveRescheduleBanner />

      {/* 2. Welcome & Hero Action Banner */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-indigo-950 via-slate-900 to-indigo-900/60 border border-indigo-500/30 p-5 sm:p-7 shadow-xl shadow-indigo-500/5">
        <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-5">
          <div className="space-y-1.5 max-w-xl">
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                {profile.course} • {profile.semester}
              </span>
              <span className="text-xs text-slate-400">
                Hi {profile.name.split(' ')[0]} 👋
              </span>
            </div>
            <h2 className="text-xl sm:text-2xl font-black text-white tracking-tight">
              Ready to conquer today&apos;s academic goals?
            </h2>
            <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
              StudyPilot has organized your workload based on your <strong className="text-white capitalize">{profile.currentEnergy} Energy</strong> mode and {profile.quickTimeBudget || profile.dailyAvailableHours}h daily budget.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3 w-full md:w-auto">
            <button
              onClick={onOpenWhatToStudy}
              className="flex-1 md:flex-none px-4 py-3 rounded-xl bg-gradient-to-r from-indigo-600 via-indigo-500 to-violet-600 hover:from-indigo-500 hover:to-violet-500 text-white font-bold text-xs sm:text-sm shadow-lg shadow-indigo-600/30 hover:scale-[1.02] active:scale-[0.98] transition-all flex items-center justify-center gap-2 cursor-pointer border border-indigo-400/30"
            >
              <Sparkles className="w-4 h-4 text-amber-300 animate-pulse" />
              <span>What should I study now?</span>
            </button>

            <button
              onClick={() => startFocusMode()}
              className="px-3.5 py-3 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 hover:border-slate-600 text-slate-200 font-semibold text-xs sm:text-sm flex items-center justify-center gap-2 transition-all cursor-pointer"
            >
              <Play className="w-4 h-4 fill-slate-200" />
              <span>Focus Mode</span>
            </button>
          </div>
        </div>
      </div>

      {/* 3. Top Metrics Row */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        {/* Metric 1: Today's Study Hours */}
        <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs font-medium">Study Schedule</span>
            <Clock className="w-4 h-4 text-indigo-400" />
          </div>
          <div>
            <div className="text-xl sm:text-2xl font-bold text-white">
              {(totalScheduledMinutes / 60).toFixed(1)} <span className="text-xs font-normal text-slate-400">/ {profile.quickTimeBudget || profile.dailyAvailableHours}h target</span>
            </div>
            <div className="w-full bg-slate-800 rounded-full h-1.5 mt-2.5 overflow-hidden">
              <div
                className="bg-indigo-500 h-1.5 rounded-full transition-all"
                style={{ width: `${Math.min(100, (totalScheduledMinutes / ((profile.quickTimeBudget || profile.dailyAvailableHours) * 60)) * 100)}%` }}
              />
            </div>
          </div>
        </div>

        {/* Metric 2: Completed vs Pending Tasks */}
        <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs font-medium">Task Progress</span>
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          </div>
          <div>
            <div className="text-xl sm:text-2xl font-bold text-white">
              {completedTasks.length} <span className="text-xs font-normal text-slate-400">/ {tasks.length} done</span>
            </div>
            <p className="text-[11px] text-slate-400 mt-2">
              {pendingTasks.length} pending ({criticalTasks.length} high priority)
            </p>
          </div>
        </div>

        {/* Metric 3: Exam Countdown */}
        <div
          onClick={() => setCurrentView('exams')}
          className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 hover:border-slate-700 cursor-pointer flex flex-col justify-between transition-colors group"
        >
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs font-medium">Next Exam Countdown</span>
            <GraduationCap className="w-4 h-4 text-rose-400" />
          </div>
          <div>
            <div className="text-xl sm:text-2xl font-bold text-rose-400 flex items-center gap-1.5">
              <span>{nearestExam ? `${nearestExam.daysRemaining} Days` : 'None'}</span>
            </div>
            <p className="text-[11px] text-slate-300 mt-1 truncate">
              {nearestExam ? nearestExam.title : 'All clear'}
            </p>
          </div>
        </div>

        {/* Metric 4: Productivity & Streak */}
        <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs font-medium">Productivity Index</span>
            <Flame className="w-4 h-4 text-amber-400" />
          </div>
          <div>
            <div className="text-xl sm:text-2xl font-bold text-amber-400 flex items-center gap-2">
              <span>{productivityScore}%</span>
              <span className="text-xs text-slate-300 font-medium">🔥 {profile.streakDays}d streak</span>
            </div>
            <p className="text-[11px] text-slate-400 mt-1">
              {profile.studyPoints} Academic XP earned
            </p>
          </div>
        </div>
      </div>

      {/* 4. Main Two Column Section */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Columns: Priority Tasks & Today's Study Schedule */}
        <div className="lg:col-span-2 space-y-6">
          {/* Priority Tasks Card */}
          <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-bold text-base text-white flex items-center gap-2">
                  <Zap className="w-4 h-4 text-amber-400" />
                  Priority Tasks (Auto-Ranked)
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  Calculated using deadline + difficulty + exam proximity + weak subject weighting
                </p>
              </div>
              <button
                onClick={onOpenAddTask}
                className="text-xs font-semibold text-indigo-400 hover:text-indigo-300 flex items-center gap-1 cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" /> Add Task
              </button>
            </div>

            <div className="space-y-3">
              {pendingTasks.slice(0, 4).map((task) => {
                const priorityBadge = {
                  critical: 'bg-rose-500/20 text-rose-300 border-rose-500/30',
                  high: 'bg-amber-500/20 text-amber-300 border-amber-500/30',
                  medium: 'bg-indigo-500/20 text-indigo-300 border-indigo-500/30',
                  low: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30',
                }[task.calculatedPriority];

                return (
                  <div
                    key={task.id}
                    className="p-3.5 rounded-xl bg-slate-950 border border-slate-800/80 hover:border-slate-700 transition-all space-y-2.5"
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div className="space-y-1">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded-md border ${priorityBadge}`}>
                            {task.calculatedPriority}
                          </span>
                          <span className="text-xs font-semibold text-slate-400">
                            {task.subjectName}
                          </span>
                          <span className="text-[11px] text-slate-500">
                            • Due: {task.deadline}
                          </span>
                        </div>
                        <h4 className="text-sm font-bold text-white">
                          {task.title}
                        </h4>
                      </div>

                      <div className="flex items-center gap-2 shrink-0">
                        <button
                          onClick={() => startFocusMode(task.id)}
                          className="px-2.5 py-1.5 rounded-lg bg-indigo-600/20 hover:bg-indigo-600/40 text-indigo-300 border border-indigo-500/30 text-xs font-medium flex items-center gap-1 cursor-pointer"
                          title="Start focus timer on this task"
                        >
                          <Play className="w-3 h-3 fill-indigo-300" />
                          <span className="hidden sm:inline">Focus</span>
                        </button>
                        <button
                          onClick={() => markTaskStatus(task.id, 'completed')}
                          className="p-1.5 rounded-lg bg-slate-800 hover:bg-emerald-600/30 text-slate-400 hover:text-emerald-400 border border-slate-700 transition-colors"
                          title="Mark task completed"
                        >
                          <CheckCircle2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>

                    {/* Transparent Priority Explanation */}
                    <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-[11px] text-slate-400">
                      <span className="truncate pr-2">
                        <strong className="text-slate-300">Why prioritized:</strong> {task.priorityReason}
                      </span>
                      <span className="shrink-0 font-mono text-slate-500">
                        ~{task.estimatedMinutes}m
                      </span>
                    </div>
                  </div>
                );
              })}

              {pendingTasks.length === 0 && (
                <div className="py-8 text-center text-slate-400 text-xs">
                  🎉 All tasks finished! Click &quot;Add Task&quot; or &quot;AI Study Breakdown&quot; to plan next.
                </div>
              )}
            </div>
          </div>

          {/* Today's Study Plan Timeline */}
          <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-bold text-base text-white flex items-center gap-2">
                  <Calendar className="w-4 h-4 text-indigo-400" />
                  Today&apos;s Smart Study Sessions
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  Optimal slots distributed with 15-minute cognitive rest buffers
                </p>
              </div>
              <button
                onClick={() => setCurrentView('planner')}
                className="text-xs font-semibold text-indigo-400 hover:text-indigo-300 flex items-center gap-1"
              >
                <span>Full Schedule</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="space-y-2.5">
              {sessions.map((sess) => (
                <div
                  key={sess.id}
                  className={`p-3.5 rounded-xl border flex items-center justify-between gap-3 text-xs transition-all ${
                    sess.isCompleted
                      ? 'bg-slate-950/40 border-slate-800 text-slate-500 line-through'
                      : sess.isRescheduled
                      ? 'bg-amber-950/20 border-amber-500/40 text-slate-200'
                      : 'bg-slate-950 border-slate-800 text-slate-200'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div
                      className="w-2.5 h-9 rounded-full shrink-0"
                      style={{ backgroundColor: sess.subjectColor }}
                    />
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-semibold text-white">{sess.taskTitle}</span>
                        {sess.isRescheduled && (
                          <span className="text-[10px] bg-amber-500/20 text-amber-300 px-1.5 py-0.2 rounded border border-amber-500/30">
                            Rescheduled
                          </span>
                        )}
                      </div>
                      <span className="text-[11px] text-slate-400 flex items-center gap-1.5 mt-0.5">
                        <Clock className="w-3 h-3 text-indigo-400" />
                        {sess.timeSlotString} • {sess.subjectName} ({sess.durationMinutes}m)
                      </span>
                    </div>
                  </div>

                  <button
                    onClick={() => startFocusMode(sess.taskId)}
                    className="px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white font-medium text-xs flex items-center gap-1.5 shrink-0 cursor-pointer"
                  >
                    <Play className="w-3 h-3 fill-white" />
                    <span>Start Session</span>
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right 1 Column: Weak Subjects & Exam Countdown Radar */}
        <div className="space-y-6">
          {/* Weak Subject Detection Alert */}
          <div className="p-5 rounded-2xl bg-gradient-to-b from-indigo-950/50 to-slate-900 border border-indigo-500/30 space-y-3.5">
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-rose-500/20 text-rose-300 border border-rose-500/30 flex items-center gap-1">
                <AlertTriangle className="w-3 h-3" />
                Weak Subject Detection
              </span>
              <button
                onClick={() => setCurrentView('subjects')}
                className="text-[11px] text-indigo-400 hover:underline"
              >
                Radar
              </button>
            </div>

            <h4 className="text-sm font-bold text-white">
              Targeted Attention Needed
            </h4>

            {weakSubjects.length > 0 ? (
              <div className="space-y-2.5">
                {weakSubjects.map((sub) => (
                  <div key={sub.id} className="p-3 rounded-xl bg-slate-950/80 border border-slate-800 text-xs space-y-1.5">
                    <div className="flex items-center justify-between">
                      <span className="font-semibold text-white">{sub.name}</span>
                      <span className="text-rose-400 font-mono font-bold">{sub.confidenceScore}% confidence</span>
                    </div>
                    <div className="w-full bg-slate-800 rounded-full h-1.5 overflow-hidden">
                      <div
                        className="bg-rose-500 h-1.5 rounded-full"
                        style={{ width: `${sub.confidenceScore}%` }}
                      />
                    </div>
                    <p className="text-[11px] text-slate-400 leading-snug">
                      Practice performance is lower than other subjects. StudyPilot scheduled 45m focused practice sessions.
                    </p>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-xs text-slate-400">All subjects in safe confidence territory!</p>
            )}
          </div>

          {/* Exam Countdown & Preparation Radar */}
          <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-3.5">
            <div className="flex items-center justify-between">
              <h4 className="text-sm font-bold text-white flex items-center gap-2">
                <GraduationCap className="w-4 h-4 text-indigo-400" />
                Upcoming Exams
              </h4>
              <button
                onClick={() => setCurrentView('exams')}
                className="text-[11px] text-indigo-400 hover:underline"
              >
                View all
              </button>
            </div>

            <div className="space-y-2.5">
              {exams.map((exam) => (
                <div
                  key={exam.id}
                  className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-xs space-y-1.5"
                >
                  <div className="flex items-center justify-between">
                    <span className="font-semibold text-white truncate max-w-[170px]">
                      {exam.subjectName}
                    </span>
                    <span
                      className={`font-mono font-bold px-2 py-0.5 rounded-md ${
                        exam.daysRemaining <= 5
                          ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                          : 'bg-slate-800 text-slate-300'
                      }`}
                    >
                      {exam.daysRemaining} days left
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-[11px] text-slate-400">
                    <span>Prep: {exam.preparedHours}h / {exam.estimatedHoursNeeded}h needed</span>
                    <span>{Math.round((exam.preparedHours / exam.estimatedHoursNeeded) * 100)}%</span>
                  </div>
                  <div className="w-full bg-slate-800 rounded-full h-1.5 overflow-hidden">
                    <div
                      className="bg-indigo-500 h-1.5 rounded-full"
                      style={{ width: `${Math.min(100, (exam.preparedHours / exam.estimatedHoursNeeded) * 100)}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
