import React from 'react';
import {
  Compass,
  Sparkles,
  ArrowRight,
  Zap,
  RefreshCw,
  Timer,
  CheckCircle2,
  Calendar,
  Layers,
  Flame,
  Award,
  ShieldAlert,
} from 'lucide-react';
import { useApp } from '../context/AppContext';

export const LandingView: React.FC<{
  onOpenWhatToStudy: () => void;
  onOpenJudgeTour: () => void;
}> = ({ onOpenWhatToStudy, onOpenJudgeTour }) => {
  const { setCurrentView } = useApp();

  return (
    <div className="space-y-12 pb-16">
      {/* Hero Section */}
      <div className="relative text-center py-12 sm:py-16 overflow-hidden rounded-3xl bg-gradient-to-b from-indigo-950/70 via-slate-900 to-slate-950 border border-indigo-500/30 p-6 sm:p-12 shadow-2xl">
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-96 h-96 bg-indigo-500/15 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 max-w-3xl mx-auto space-y-5">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-indigo-500/15 border border-indigo-500/30 text-indigo-300 text-xs font-semibold">
            <Sparkles className="w-4 h-4 text-amber-300" />
            <span>Built for College Hackathons &amp; Academic Excellence</span>
          </div>

          <h1 className="text-3xl sm:text-5xl font-black text-white tracking-tight leading-tight">
            StudyPilot <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 via-sky-300 to-emerald-400">
              Your AI-Powered Academic Co-Pilot
            </span>
          </h1>

          <p className="text-sm sm:text-lg text-slate-300 font-medium max-w-xl mx-auto">
            Plan smarter. Study better. Never miss a deadline.
          </p>

          <p className="text-xs sm:text-sm text-slate-400 max-w-lg mx-auto">
            Normal to-do apps only store tasks. StudyPilot understands academic workload, calculates what to study first, and automatically reschedules missed sessions.
          </p>

          <div className="flex flex-wrap items-center justify-center gap-3 pt-3">
            <button
              onClick={() => setCurrentView('dashboard')}
              className="px-6 py-3 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-sm shadow-lg shadow-indigo-600/30 flex items-center gap-2 cursor-pointer hover:scale-[1.02] active:scale-[0.98] transition-all"
            >
              <span>Get Started</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            <button
              onClick={onOpenJudgeTour}
              className="px-5 py-3 rounded-xl bg-slate-900 hover:bg-slate-800 border border-amber-500/40 text-amber-300 font-bold text-sm flex items-center gap-2 cursor-pointer transition-all"
            >
              <Zap className="w-4 h-4 text-amber-400" />
              <span>2-Min Judge Demo</span>
            </button>
          </div>
        </div>
      </div>

      {/* 3 Main Benefits Pillars (Requirement 23) */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="p-6 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-3">
          <div className="w-12 h-12 rounded-xl bg-indigo-500/20 text-indigo-400 flex items-center justify-center">
            <Calendar className="w-6 h-6" />
          </div>
          <h3 className="font-bold text-lg text-white">1. Smart Planning</h3>
          <p className="text-xs text-slate-400 leading-relaxed">
            Considers deadlines, exam proximity, subject difficulty, and your daily available hours to generate realistic daily time slots with rest buffers.
          </p>
        </div>

        <div className="p-6 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-3">
          <div className="w-12 h-12 rounded-xl bg-amber-500/20 text-amber-300 flex items-center justify-center">
            <RefreshCw className="w-6 h-6" />
          </div>
          <h3 className="font-bold text-lg text-white">2. Adaptive Rescheduling</h3>
          <p className="text-xs text-slate-400 leading-relaxed">
            Missed a session? StudyPilot never shames with red overdue tags. It automatically shifts work into your next free window and preserves exam revision.
          </p>
        </div>

        <div className="p-6 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-3">
          <div className="w-12 h-12 rounded-xl bg-emerald-500/20 text-emerald-300 flex items-center justify-center">
            <Timer className="w-6 h-6" />
          </div>
          <h3 className="font-bold text-lg text-white">3. Focused Learning</h3>
          <p className="text-xs text-slate-400 leading-relaxed">
            Distraction-free Pomodoro mode with post-session reflection (&quot;Did you finish?&quot;) feeding real student progress back into future schedule optimization.
          </p>
        </div>
      </div>

      {/* Core Hackathon Innovation Comparison Matrix */}
      <div className="p-6 sm:p-8 rounded-3xl bg-slate-900/80 border border-indigo-500/30 space-y-5">
        <div className="text-center space-y-1">
          <span className="text-[10px] uppercase font-bold tracking-widest text-indigo-400">
            Why Hackathon Judges Love StudyPilot
          </span>
          <h2 className="text-xl sm:text-2xl font-black text-white">
            The Fundamental Paradigm Shift
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
          {/* Normal Apps */}
          <div className="p-5 rounded-2xl bg-slate-950 border border-slate-800 space-y-3">
            <div className="flex items-center gap-2 text-rose-400 font-bold text-sm">
              <span>✕ Standard To-Do App</span>
            </div>
            <ul className="space-y-2 text-xs text-slate-400">
              <li className="flex items-start gap-2">
                <span>•</span>
                <span>Only tells students <strong>WHAT</strong> tasks they have in an overwhelming linear list.</span>
              </li>
              <li className="flex items-start gap-2">
                <span>•</span>
                <span>Sorts dumbly by date without considering exam weight or weak subjects.</span>
              </li>
              <li className="flex items-start gap-2">
                <span>•</span>
                <span>Marks missed tasks as &quot;Overdue&quot;, creating guilt and academic burnout.</span>
              </li>
              <li className="flex items-start gap-2">
                <span>•</span>
                <span>No understanding of fatigue or student energy levels.</span>
              </li>
            </ul>
          </div>

          {/* StudyPilot */}
          <div className="p-5 rounded-2xl bg-gradient-to-b from-indigo-950/60 to-slate-950 border border-indigo-500/40 space-y-3 shadow-lg shadow-indigo-500/5">
            <div className="flex items-center gap-2 text-emerald-400 font-bold text-sm">
              <span>✓ StudyPilot AI Co-Pilot</span>
            </div>
            <ul className="space-y-2 text-xs text-slate-200">
              <li className="flex items-start gap-2">
                <span className="text-emerald-400">✔</span>
                <span>Decides <strong>WHAT</strong> to study, <strong>WHEN</strong> to study, &amp; <strong>WHY</strong> it matters right now.</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-emerald-400">✔</span>
                <span>Distributes work across spaced Pomodoro slots with break buffers.</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-emerald-400">✔</span>
                <span>Automatically reorganizes remaining workload when plans change.</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-emerald-400">✔</span>
                <span>Energy-based planning: matches deep work to high energy, light reviews to low energy.</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="pt-4 text-center">
          <button
            onClick={() => setCurrentView('dashboard')}
            className="px-6 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs sm:text-sm shadow-md shadow-indigo-600/30 cursor-pointer"
          >
            Launch StudyPilot Dashboard
          </button>
        </div>
      </div>
    </div>
  );
};
