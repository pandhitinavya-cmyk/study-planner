import React from 'react';
import {
  BarChart3,
  TrendingUp,
  Clock,
  CheckCircle2,
  Flame,
  Award,
  Zap,
  RotateCcw,
  BookOpen,
  Calendar,
} from 'lucide-react';
import { useApp } from '../context/AppContext';

export const AnalyticsView: React.FC = () => {
  const { profile, tasks, subjects, achievements } = useApp();

  const completedTasks = tasks.filter((t) => t.status === 'completed');
  const postponedTasks = tasks.filter((t) => t.status === 'missed' || t.status === 'partially_completed');

  // Weekly study data
  const daysOfWeek = [
    { day: 'Mon', planned: 3.5, actual: 3.0 },
    { day: 'Tue', planned: 3.0, actual: 3.5 },
    { day: 'Wed', planned: 4.0, actual: 3.8 },
    { day: 'Thu', planned: 3.5, actual: 3.2 },
    { day: 'Fri (Today)', planned: 3.5, actual: 2.5 },
    { day: 'Sat', planned: 2.0, actual: 0.0 },
    { day: 'Sun', planned: 2.5, actual: 0.0 },
  ];

  const totalPlannedHours = daysOfWeek.reduce((acc, d) => acc + d.planned, 0);
  const totalActualHours = daysOfWeek.reduce((acc, d) => acc + d.actual, 0);

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div>
        <h2 className="text-xl sm:text-2xl font-bold text-white flex items-center gap-2">
          <BarChart3 className="w-6 h-6 text-indigo-400" />
          Productivity Analytics &amp; Gamification
        </h2>
        <p className="text-xs sm:text-sm text-slate-400 mt-1">
          Evidence-based academic tracking: planned vs actual study time, adaptive metrics, and badges
        </p>
      </div>

      {/* Top Highlight Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800">
          <span className="text-xs text-slate-400 flex items-center gap-1.5">
            <Clock className="w-4 h-4 text-indigo-400" /> Actual Study Time
          </span>
          <div className="text-2xl font-black text-white mt-2">
            {totalActualHours.toFixed(1)}h <span className="text-xs font-normal text-slate-400">/ {totalPlannedHours.toFixed(1)}h</span>
          </div>
          <p className="text-[11px] text-emerald-400 mt-1 font-semibold">
            {Math.round((totalActualHours / totalPlannedHours) * 100)}% adherence rate
          </p>
        </div>

        <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800">
          <span className="text-xs text-slate-400 flex items-center gap-1.5">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" /> Completed Tasks
          </span>
          <div className="text-2xl font-black text-emerald-400 mt-2">
            {completedTasks.length} <span className="text-xs font-normal text-slate-400">tasks</span>
          </div>
          <p className="text-[11px] text-slate-400 mt-1">
            {postponedTasks.length} adapted &amp; rescheduled
          </p>
        </div>

        <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800">
          <span className="text-xs text-slate-400 flex items-center gap-1.5">
            <Flame className="w-4 h-4 text-amber-400" /> Consistency Streak
          </span>
          <div className="text-2xl font-black text-amber-400 mt-2">
            {profile.streakDays} Days
          </div>
          <p className="text-[11px] text-slate-400 mt-1">
            Top productive period: <strong>Evening</strong>
          </p>
        </div>

        <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800">
          <span className="text-xs text-slate-400 flex items-center gap-1.5">
            <Award className="w-4 h-4 text-indigo-400" /> Student XP
          </span>
          <div className="text-2xl font-black text-indigo-400 mt-2">
            {profile.studyPoints} XP
          </div>
          <p className="text-[11px] text-slate-400 mt-1">
            Level 4: Dedicated Scholar
          </p>
        </div>
      </div>

      {/* Planned vs Actual Weekly Chart */}
      <div className="p-5 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="font-bold text-base text-white flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-indigo-400" />
              Planned vs Actual Study Hours (Weekly)
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Tracks whether your scheduled study time matched reality
            </p>
          </div>
          <div className="flex items-center gap-3 text-xs">
            <span className="flex items-center gap-1.5 text-slate-400">
              <span className="w-3 h-3 rounded-xs bg-slate-700" /> Planned
            </span>
            <span className="flex items-center gap-1.5 text-indigo-400">
              <span className="w-3 h-3 rounded-xs bg-indigo-500" /> Actual
            </span>
          </div>
        </div>

        {/* Visual Bar Comparison */}
        <div className="grid grid-cols-7 gap-2 pt-4 items-end h-48 border-b border-slate-800 pb-2">
          {daysOfWeek.map((d) => {
            const maxVal = 5;
            const plannedHeight = (d.planned / maxVal) * 100;
            const actualHeight = (d.actual / maxVal) * 100;

            return (
              <div key={d.day} className="flex flex-col items-center h-full justify-end gap-1.5">
                <div className="w-full flex items-end justify-center gap-1 h-36">
                  {/* Planned Bar */}
                  <div
                    className="w-3 sm:w-4 bg-slate-800 rounded-t-sm"
                    style={{ height: `${plannedHeight}%` }}
                    title={`Planned: ${d.planned}h`}
                  />
                  {/* Actual Bar */}
                  <div
                    className="w-3 sm:w-4 bg-indigo-500 rounded-t-sm"
                    style={{ height: `${actualHeight}%` }}
                    title={`Actual: ${d.actual}h`}
                  />
                </div>
                <span className="text-[10px] text-slate-400 font-mono text-center truncate w-full">
                  {d.day}
                </span>
              </div>
            );
          })}
        </div>
      </div>

      {/* Subject-Wise Time Allocation */}
      <div className="p-5 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-4">
        <h3 className="font-bold text-base text-white flex items-center gap-2">
          <BookOpen className="w-4 h-4 text-indigo-400" />
          Subject-Wise Study Investment
        </h3>

        <div className="space-y-3">
          {subjects.map((sub) => {
            const percent = Math.min(100, Math.round((sub.totalHoursStudied / sub.targetWeeklyHours) * 100));

            return (
              <div key={sub.id} className="space-y-1 text-xs">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span
                      className="w-2.5 h-2.5 rounded-full"
                      style={{ backgroundColor: sub.color }}
                    />
                    <span className="font-semibold text-white">{sub.name}</span>
                  </div>
                  <span className="text-slate-400 font-mono">
                    {sub.totalHoursStudied}h / {sub.targetWeeklyHours}h ({percent}%)
                  </span>
                </div>
                <div className="w-full bg-slate-800 rounded-full h-2 overflow-hidden">
                  <div
                    className="h-2 rounded-full"
                    style={{ width: `${percent}%`, backgroundColor: sub.color }}
                  />
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Gamification: Badges & Milestones */}
      <div className="p-5 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-4">
        <div>
          <h3 className="font-bold text-base text-white flex items-center gap-2">
            <Award className="w-4 h-4 text-amber-400" />
            Academic Milestone Badges
          </h3>
          <p className="text-xs text-slate-400 mt-0.5">
            Earn rewards for consistency, ahead-of-time submissions, and adaptive rescheduling
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {achievements.map((badge) => (
            <div
              key={badge.id}
              className={`p-3.5 rounded-xl border flex items-start gap-3 transition-all ${
                badge.unlocked
                  ? 'bg-slate-950 border-amber-500/30'
                  : 'bg-slate-950/40 border-slate-800/80 opacity-60'
              }`}
            >
              <div className="text-2xl p-2 rounded-xl bg-slate-900 border border-slate-800 shrink-0">
                {badge.icon}
              </div>
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <h4 className="font-bold text-white text-xs">{badge.title}</h4>
                  {badge.unlocked && (
                    <span className="text-[9px] font-bold uppercase px-1.5 py-0.2 rounded bg-amber-500/20 text-amber-300">
                      Unlocked
                    </span>
                  )}
                </div>
                <p className="text-[11px] text-slate-400 leading-snug">{badge.description}</p>
                {badge.maxProgress && !badge.unlocked && (
                  <div className="pt-1">
                    <span className="text-[10px] text-slate-500">
                      Progress: {badge.progress}/{badge.maxProgress}
                    </span>
                    <div className="w-full bg-slate-800 rounded-full h-1 mt-0.5">
                      <div
                        className="bg-amber-400 h-1 rounded-full"
                        style={{ width: `${((badge.progress || 0) / badge.maxProgress) * 100}%` }}
                      />
                    </div>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
