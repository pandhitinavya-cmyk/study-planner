import React, { useState } from 'react';
import {
  BookOpen,
  Plus,
  AlertTriangle,
  CheckCircle2,
  TrendingUp,
  Clock,
  Sparkles,
  Zap,
  Sliders,
  Trash2,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { Subject } from '../types';
import { getTodayDateString } from '../utils/demoData';

export const SubjectsView: React.FC = () => {
  const { subjects, updateSubject, addSubject, deleteSubject, addTask, setCurrentView } = useApp();

  const [isAdding, setIsAdding] = useState(false);
  const [newSubName, setNewSubName] = useState('');
  const [newSubCode, setNewSubCode] = useState('');
  const [newSubDiff, setNewSubDiff] = useState<'easy' | 'medium' | 'hard'>('medium');
  const [newSubWeeklyHours, setNewSubWeeklyHours] = useState(5);

  const handleAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newSubName.trim()) return;

    addSubject({
      name: newSubName.trim(),
      code: newSubCode.trim() || 'SUB-101',
      color: '#6366f1',
      difficulty: newSubDiff,
      isWeakSubject: false,
      confidenceScore: 70,
      totalHoursStudied: 0,
      targetWeeklyHours: newSubWeeklyHours,
      performanceRating: 75,
      syllabusProgress: 20,
    });

    setIsAdding(false);
    setNewSubName('');
    setNewSubCode('');
  };

  const handleBoostSubject = (sub: Subject) => {
    // Add an intelligent revision task without overloading
    addTask({
      title: `${sub.name} Targeted Conceptual Drill & Practice`,
      type: 'revision',
      subjectId: sub.id,
      subjectName: sub.name,
      deadline: getTodayDateString(2),
      estimatedMinutes: 40,
      difficulty: sub.difficulty,
      importance: 'high',
      status: 'pending',
      progressPercent: 0,
      scheduledDate: getTodayDateString(0),
      scheduledTimeSlot: '08:00 PM - 08:40 PM',
      subtasks: [
        { id: `b-${Date.now()}-1`, title: 'Review weak lecture module slides', completed: false, estimatedMinutes: 20 },
        { id: `b-${Date.now()}-2`, title: 'Solve 2 self-assessment practice questions', completed: false, estimatedMinutes: 20 },
      ],
      notes: 'StudyPilot Weak Subject Reinforcement Session',
    });

    setCurrentView('planner');
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-bold text-white flex items-center gap-2">
            <BookOpen className="w-6 h-6 text-indigo-400" />
            Subjects &amp; Weak Area Radar
          </h2>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Detects subjects that need reinforcement and dynamically balances your workload
          </p>
        </div>

        <button
          onClick={() => setIsAdding(!isAdding)}
          className="px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs flex items-center gap-2 shadow-md shadow-indigo-600/30 cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>Add Subject</span>
        </button>
      </div>

      {/* Add Subject Collapsible Form */}
      {isAdding && (
        <form
          onSubmit={handleAddSubmit}
          className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-3.5"
        >
          <h3 className="font-bold text-sm text-white">Add New Subject</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            <div>
              <label className="block text-xs text-slate-400 mb-1">Subject Name</label>
              <input
                type="text"
                required
                placeholder="e.g. Operating Systems"
                value={newSubName}
                onChange={(e) => setNewSubName(e.target.value)}
                className="w-full px-3 py-1.5 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white"
              />
            </div>
            <div>
              <label className="block text-xs text-slate-400 mb-1">Course Code</label>
              <input
                type="text"
                placeholder="CS-303"
                value={newSubCode}
                onChange={(e) => setNewSubCode(e.target.value)}
                className="w-full px-3 py-1.5 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white"
              />
            </div>
            <div>
              <label className="block text-xs text-slate-400 mb-1">Difficulty</label>
              <select
                value={newSubDiff}
                onChange={(e) => setNewSubDiff(e.target.value as any)}
                className="w-full px-3 py-1.5 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white"
              >
                <option value="easy">Easy</option>
                <option value="medium">Medium</option>
                <option value="hard">Hard</option>
              </select>
            </div>
            <div>
              <label className="block text-xs text-slate-400 mb-1">Weekly Target Hours</label>
              <input
                type="number"
                min="1"
                max="20"
                value={newSubWeeklyHours}
                onChange={(e) => setNewSubWeeklyHours(Number(e.target.value))}
                className="w-full px-3 py-1.5 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white"
              />
            </div>
          </div>
          <div className="flex items-center justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => setIsAdding(false)}
              className="px-3 py-1.5 text-xs text-slate-400 hover:text-white"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-1.5 rounded-xl bg-indigo-600 text-white text-xs font-semibold"
            >
              Save Subject
            </button>
          </div>
        </form>
      )}

      {/* Weak Subjects Banner Callout */}
      <div className="p-4 rounded-2xl bg-gradient-to-r from-rose-950/40 via-indigo-950/40 to-slate-900 border border-rose-500/30 flex items-start gap-3.5">
        <div className="p-2 rounded-xl bg-rose-500/20 text-rose-300 border border-rose-500/30 shrink-0 mt-0.5">
          <AlertTriangle className="w-5 h-5" />
        </div>
        <div>
          <h4 className="font-bold text-white text-sm">
            AI Weak Subject Diagnostic Report
          </h4>
          <p className="text-xs text-slate-300 mt-1 leading-relaxed max-w-2xl">
            Subjects marked with &lt;60% confidence are automatically factored into the Smart Priority Engine. StudyPilot allocates targeted revision blocks ahead of exam dates without creating an unrealistic workload.
          </p>
        </div>
      </div>

      {/* Subject Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {subjects.map((sub) => {
          const isWeak = sub.isWeakSubject || sub.confidenceScore < 60;

          return (
            <div
              key={sub.id}
              className={`p-5 rounded-2xl border transition-all space-y-4 ${
                isWeak
                  ? 'bg-slate-900 border-rose-500/30 shadow-md shadow-rose-500/5'
                  : 'bg-slate-900/80 border-slate-800'
              }`}
            >
              <div className="flex items-start justify-between gap-2">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-[10px] px-2 py-0.5 rounded-md bg-slate-800 text-slate-300">
                      {sub.code}
                    </span>
                    {isWeak && (
                      <span className="text-[10px] font-bold uppercase px-2 py-0.5 rounded-md bg-rose-500/20 text-rose-300 border border-rose-500/30">
                        Needs Attention
                      </span>
                    )}
                  </div>
                  <h3 className="font-bold text-base text-white mt-1">
                    {sub.name}
                  </h3>
                </div>

                <button
                  onClick={() => deleteSubject(sub.id)}
                  className="text-slate-600 hover:text-rose-400 p-1"
                  title="Delete subject"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>

              {/* Confidence Meter Slider */}
              <div className="space-y-1.5">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-slate-400">Subject Confidence:</span>
                  <span
                    className={`font-mono font-bold ${
                      sub.confidenceScore >= 70
                        ? 'text-emerald-400'
                        : sub.confidenceScore >= 55
                        ? 'text-amber-400'
                        : 'text-rose-400'
                    }`}
                  >
                    {sub.confidenceScore}%
                  </span>
                </div>
                <input
                  type="range"
                  min="20"
                  max="100"
                  value={sub.confidenceScore}
                  onChange={(e) => {
                    const val = Number(e.target.value);
                    updateSubject(sub.id, {
                      confidenceScore: val,
                      isWeakSubject: val < 60,
                    });
                  }}
                  className="w-full accent-indigo-500 cursor-pointer"
                />
              </div>

              {/* Stats */}
              <div className="grid grid-cols-2 gap-2 text-xs pt-1 border-t border-slate-800/80">
                <div>
                  <span className="text-[11px] text-slate-500 block">Weekly Study</span>
                  <span className="font-bold text-white">
                    {sub.totalHoursStudied}h / {sub.targetWeeklyHours}h
                  </span>
                </div>
                <div>
                  <span className="text-[11px] text-slate-500 block">Difficulty</span>
                  <span className="font-semibold text-slate-300 capitalize">
                    {sub.difficulty}
                  </span>
                </div>
              </div>

              {/* Action Button */}
              {isWeak && (
                <button
                  onClick={() => handleBoostSubject(sub)}
                  className="w-full py-2 px-3 rounded-xl bg-gradient-to-r from-rose-600 to-indigo-600 hover:from-rose-500 hover:to-indigo-500 text-white font-semibold text-xs flex items-center justify-center gap-1.5 shadow-md shadow-rose-600/20 cursor-pointer transition-all"
                >
                  <Sparkles className="w-3.5 h-3.5 text-amber-300" />
                  <span>Boost Study Plan (Schedule Practice)</span>
                </button>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};
