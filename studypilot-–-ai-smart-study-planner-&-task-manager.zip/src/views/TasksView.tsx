import React, { useState } from 'react';
import {
  CheckSquare,
  Plus,
  Sparkles,
  Search,
  Filter,
  CheckCircle2,
  Clock,
  Calendar,
  Layers,
  ChevronDown,
  ChevronRight,
  Play,
  Trash2,
  AlertTriangle,
  RotateCcw,
  Zap,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { Task, TaskType, PriorityLevel, TaskStatus } from '../types';

interface TasksViewProps {
  onOpenAddTask: () => void;
  onOpenAiBreakdown: () => void;
}

export const TasksView: React.FC<TasksViewProps> = ({ onOpenAddTask, onOpenAiBreakdown }) => {
  const {
    tasks,
    subjects,
    toggleSubtask,
    addSubtask,
    markTaskStatus,
    deleteTask,
    startFocusMode,
  } = useApp();

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedSubject, setSelectedSubject] = useState<string>('all');
  const [selectedPriority, setSelectedPriority] = useState<string>('all');
  const [expandedTaskIds, setExpandedTaskIds] = useState<Record<string, boolean>>({
    'task-1': true,
    'task-3': true,
  });
  const [newSubtaskInputs, setNewSubtaskInputs] = useState<Record<string, string>>({});

  const toggleExpand = (id: string) => {
    setExpandedTaskIds((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  const filteredTasks = tasks.filter((t) => {
    if (searchQuery && !t.title.toLowerCase().includes(searchQuery.toLowerCase())) return false;
    if (selectedCategory !== 'all' && t.type !== selectedCategory) return false;
    if (selectedSubject !== 'all' && t.subjectId !== selectedSubject) return false;
    if (selectedPriority !== 'all' && t.calculatedPriority !== selectedPriority) return false;
    return true;
  });

  const handleAddSubtaskSubmit = (taskId: string, e: React.FormEvent) => {
    e.preventDefault();
    const title = newSubtaskInputs[taskId];
    if (!title || !title.trim()) return;
    addSubtask(taskId, title.trim());
    setNewSubtaskInputs((prev) => ({ ...prev, [taskId]: '' }));
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-bold text-white flex items-center gap-2">
            <CheckSquare className="w-6 h-6 text-indigo-400" />
            My Tasks &amp; Project Manager
          </h2>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Track assignments, lab records, projects, and exam milestones with intelligent priority ranking
          </p>
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto">
          <button
            onClick={onOpenAiBreakdown}
            className="flex-1 sm:flex-none px-3.5 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-indigo-500/30 text-indigo-300 font-medium text-xs flex items-center justify-center gap-2 cursor-pointer transition-colors"
          >
            <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
            <span>AI Breakdown</span>
          </button>
          <button
            onClick={onOpenAddTask}
            className="flex-1 sm:flex-none px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs flex items-center justify-center gap-2 shadow-md shadow-indigo-600/30 cursor-pointer transition-colors"
          >
            <Plus className="w-4 h-4" />
            <span>+ Add Task</span>
          </button>
        </div>
      </div>

      {/* Filters & Search */}
      <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-3">
        <div className="relative">
          <Search className="w-4 h-4 text-slate-500 absolute left-3.5 top-3" />
          <input
            type="text"
            placeholder="Search assignments, projects, exam prep..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-4 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white placeholder-slate-500 focus:border-indigo-500"
          />
        </div>

        <div className="flex flex-wrap items-center gap-2 text-xs">
          <div className="flex items-center gap-1.5 text-slate-400 mr-2">
            <Filter className="w-3.5 h-3.5" />
            <span>Filters:</span>
          </div>

          {/* Category Filter */}
          <select
            value={selectedCategory}
            onChange={(e) => setSelectedCategory(e.target.value)}
            className="px-2.5 py-1.5 rounded-lg bg-slate-950 border border-slate-800 text-xs text-slate-300"
          >
            <option value="all">All Categories</option>
            <option value="assignment">Assignments</option>
            <option value="project">College Projects</option>
            <option value="exam_prep">Exam Prep</option>
            <option value="lab">Lab Records</option>
            <option value="revision">Revisions</option>
          </select>

          {/* Subject Filter */}
          <select
            value={selectedSubject}
            onChange={(e) => setSelectedSubject(e.target.value)}
            className="px-2.5 py-1.5 rounded-lg bg-slate-950 border border-slate-800 text-xs text-slate-300"
          >
            <option value="all">All Subjects</option>
            {subjects.map((sub) => (
              <option key={sub.id} value={sub.id}>
                {sub.name}
              </option>
            ))}
          </select>

          {/* Priority Filter */}
          <select
            value={selectedPriority}
            onChange={(e) => setSelectedPriority(e.target.value)}
            className="px-2.5 py-1.5 rounded-lg bg-slate-950 border border-slate-800 text-xs text-slate-300"
          >
            <option value="all">All Priorities</option>
            <option value="critical">🔴 Critical</option>
            <option value="high">🟠 High</option>
            <option value="medium">🟡 Medium</option>
            <option value="low">🟢 Low</option>
          </select>
        </div>
      </div>

      {/* Task List */}
      <div className="space-y-3.5">
        {filteredTasks.map((task) => {
          const isExpanded = !!expandedTaskIds[task.id];
          const priorityBadge = {
            critical: 'bg-rose-500/20 text-rose-300 border-rose-500/30',
            high: 'bg-amber-500/20 text-amber-300 border-amber-500/30',
            medium: 'bg-indigo-500/20 text-indigo-300 border-indigo-500/30',
            low: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30',
          }[task.calculatedPriority];

          return (
            <div
              key={task.id}
              className={`rounded-2xl border transition-all ${
                task.status === 'completed'
                  ? 'bg-slate-950/40 border-slate-800/80 opacity-70'
                  : 'bg-slate-900/90 border-slate-800 hover:border-slate-700 shadow-sm'
              }`}
            >
              {/* Task Header Row */}
              <div className="p-4 sm:p-5 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
                <div className="flex items-start gap-3 w-full md:w-auto">
                  <button
                    onClick={() => toggleExpand(task.id)}
                    className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 shrink-0 mt-0.5"
                  >
                    {isExpanded ? (
                      <ChevronDown className="w-4 h-4" />
                    ) : (
                      <ChevronRight className="w-4 h-4" />
                    )}
                  </button>

                  <div className="space-y-1 flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded-md border ${priorityBadge}`}>
                        {task.calculatedPriority}
                      </span>
                      <span className="text-[10px] font-semibold uppercase px-2 py-0.5 rounded-md bg-slate-800 text-slate-300">
                        {task.type.replace('_', ' ')}
                      </span>
                      <span className="text-xs font-semibold text-indigo-400">
                        {task.subjectName}
                      </span>
                      <span className="text-xs text-slate-400 flex items-center gap-1">
                        <Calendar className="w-3 h-3" /> Due {task.deadline}
                      </span>
                    </div>

                    <h3 className={`text-base font-bold text-white ${task.status === 'completed' ? 'line-through text-slate-400' : ''}`}>
                      {task.title}
                    </h3>

                    {/* Transparent AI Priority Explanation */}
                    <p className="text-xs text-slate-400">
                      <strong className="text-slate-300">Priority Engine: </strong>
                      {task.priorityReason}
                    </p>
                  </div>
                </div>

                {/* Progress bar & Action buttons */}
                <div className="flex items-center justify-between md:justify-end gap-3 w-full md:w-auto shrink-0 pt-2 md:pt-0 border-t md:border-t-0 border-slate-800">
                  <div className="text-right pr-2">
                    <div className="text-xs font-bold text-white flex items-center gap-1.5 justify-end">
                      <span>{task.progressPercent}%</span>
                      <span className="text-[11px] text-slate-400 font-normal">
                        ({task.subtasks.filter((s) => s.completed).length}/{task.subtasks.length || 1} steps)
                      </span>
                    </div>
                    <div className="w-24 bg-slate-800 rounded-full h-1.5 mt-1 overflow-hidden">
                      <div
                        className="bg-indigo-500 h-1.5 rounded-full transition-all"
                        style={{ width: `${task.progressPercent}%` }}
                      />
                    </div>
                  </div>

                  <div className="flex items-center gap-1.5">
                    {task.status !== 'completed' && (
                      <button
                        onClick={() => startFocusMode(task.id)}
                        className="px-3 py-1.5 rounded-xl bg-indigo-600/20 hover:bg-indigo-600/40 text-indigo-300 border border-indigo-500/30 text-xs font-medium flex items-center gap-1.5 cursor-pointer"
                        title="Start Pomodoro focus"
                      >
                        <Play className="w-3.5 h-3.5 fill-indigo-300" />
                        <span>Focus</span>
                      </button>
                    )}

                    <button
                      onClick={() => markTaskStatus(task.id, task.status === 'completed' ? 'pending' : 'completed')}
                      className={`p-2 rounded-xl border transition-colors ${
                        task.status === 'completed'
                          ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30'
                          : 'bg-slate-800 hover:bg-emerald-600/30 text-slate-400 hover:text-emerald-400 border-slate-700'
                      }`}
                      title={task.status === 'completed' ? 'Mark incomplete' : 'Mark complete'}
                    >
                      <CheckCircle2 className="w-4 h-4" />
                    </button>

                    {/* Hackathon Judge Trigger: Simulate Missed Task Adaptive Rescheduling */}
                    {task.status !== 'completed' && (
                      <button
                        onClick={() => markTaskStatus(task.id, 'partially_completed', 30)}
                        className="px-2 py-1.5 rounded-xl bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 border border-amber-500/30 text-[11px] font-medium flex items-center gap-1"
                        title="Simulate missed task to trigger adaptive rescheduling"
                      >
                        <RotateCcw className="w-3 h-3 text-amber-400" />
                        <span className="hidden xl:inline">Simulate Missed</span>
                      </button>
                    )}

                    <button
                      onClick={() => deleteTask(task.id)}
                      className="p-2 rounded-xl text-slate-500 hover:text-rose-400 hover:bg-slate-800 transition-colors"
                      title="Delete task"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>

              {/* Expanded Subtask Tree */}
              {isExpanded && (
                <div className="p-4 sm:p-5 pt-0 border-t border-slate-800/80 bg-slate-950/40 rounded-b-2xl space-y-3">
                  <div className="flex items-center justify-between text-xs font-semibold text-slate-400 pt-3">
                    <span className="flex items-center gap-1.5">
                      <Layers className="w-3.5 h-3.5 text-indigo-400" />
                      Milestones &amp; Subtasks
                    </span>
                    <span>Est: {task.estimatedMinutes} mins</span>
                  </div>

                  <div className="space-y-1.5">
                    {task.subtasks.map((st) => (
                      <div
                        key={st.id}
                        onClick={() => toggleSubtask(task.id, st.id)}
                        className={`p-2.5 rounded-xl border flex items-center justify-between gap-3 text-xs cursor-pointer transition-colors ${
                          st.completed
                            ? 'bg-slate-900/40 border-slate-800 text-slate-500 line-through'
                            : 'bg-slate-900 border-slate-800 hover:border-slate-700 text-slate-200'
                        }`}
                      >
                        <div className="flex items-center gap-2.5">
                          <input
                            type="checkbox"
                            checked={st.completed}
                            onChange={() => {}}
                            className="rounded border-slate-700 text-indigo-600 focus:ring-0 cursor-pointer"
                          />
                          <span>{st.title}</span>
                        </div>
                        <span className="font-mono text-[10px] text-slate-500">
                          {st.estimatedMinutes}m
                        </span>
                      </div>
                    ))}
                  </div>

                  {/* Add Subtask Inline Form */}
                  <form
                    onSubmit={(e) => handleAddSubtaskSubmit(task.id, e)}
                    className="flex gap-2 pt-1"
                  >
                    <input
                      type="text"
                      placeholder="Add subtask step (e.g. Write unit tests)..."
                      value={newSubtaskInputs[task.id] || ''}
                      onChange={(e) =>
                        setNewSubtaskInputs((prev) => ({ ...prev, [task.id]: e.target.value }))
                      }
                      className="flex-1 px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-800 text-xs text-white placeholder-slate-500 focus:border-indigo-500"
                    />
                    <button
                      type="submit"
                      className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-medium text-slate-200 cursor-pointer"
                    >
                      + Step
                    </button>
                  </form>
                </div>
              )}
            </div>
          );
        })}

        {filteredTasks.length === 0 && (
          <div className="py-16 text-center text-slate-400 space-y-3">
            <CheckSquare className="w-8 h-8 mx-auto text-slate-600" />
            <p className="text-sm">No tasks matched your filter.</p>
            <button
              onClick={onOpenAddTask}
              className="px-4 py-2 rounded-xl bg-indigo-600 text-white text-xs font-semibold"
            >
              Add New Task
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
