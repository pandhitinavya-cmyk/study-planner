import React, { useState } from 'react';
import {
  Compass,
  Zap,
  Flame,
  Award,
  Bell,
  Sun,
  Moon,
  RotateCcw,
  Sparkles,
  Clock,
  Menu,
  ShieldAlert,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { EnergyLevel } from '../types';

interface NavbarProps {
  onOpenWhatToStudy: () => void;
  onOpenJudgeTour: () => void;
  onToggleMobileNav: () => void;
  onOpenNotifications: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  onOpenWhatToStudy,
  onOpenJudgeTour,
  onToggleMobileNav,
  onOpenNotifications,
}) => {
  const {
    profile,
    setEnergyMode,
    setTimeBudget,
    theme,
    toggleTheme,
    resetToDemoData,
    notifications,
    setCurrentView,
  } = useApp();

  const [showTimeBudgetMenu, setShowTimeBudgetMenu] = useState(false);
  const unreadCount = notifications.filter((n) => !n.read).length;

  const energyOptions: { level: EnergyLevel; label: string; icon: string; color: string }[] = [
    { level: 'high', label: 'High Energy', icon: '⚡', color: 'text-emerald-400 bg-emerald-500/10 border-emerald-500/30' },
    { level: 'normal', label: 'Normal', icon: '⚖️', color: 'text-amber-400 bg-amber-500/10 border-amber-500/30' },
    { level: 'low', label: 'Low Energy', icon: '🌙', color: 'text-blue-400 bg-blue-500/10 border-blue-500/30' },
  ];

  return (
    <header className="sticky top-0 z-30 w-full border-b border-slate-800 bg-slate-950/80 backdrop-blur-md px-4 lg:px-6 py-2.5 transition-colors">
      <div className="flex items-center justify-between gap-2 max-w-7xl mx-auto">
        {/* Left: Mobile menu toggle & Logo */}
        <div className="flex items-center gap-3">
          <button
            onClick={onToggleMobileNav}
            className="p-2 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 lg:hidden"
            aria-label="Toggle navigation"
          >
            <Menu className="w-5 h-5" />
          </button>

          <button
            onClick={() => setCurrentView('dashboard')}
            className="flex items-center gap-2.5 group text-left"
          >
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-indigo-600 via-indigo-500 to-sky-400 flex items-center justify-center shadow-lg shadow-indigo-500/25 group-hover:scale-105 transition-transform">
              <Compass className="w-5 h-5 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-bold text-base tracking-tight text-white group-hover:text-indigo-400 transition-colors">
                  StudyPilot
                </span>
                <span className="text-[10px] font-semibold uppercase px-1.5 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                  AI
                </span>
              </div>
              <p className="text-[11px] text-slate-400 font-medium hidden sm:block">
                Academic Co-Pilot
              </p>
            </div>
          </button>
        </div>

        {/* Center: What Should I Study Now (Hero Hackathon Highlight) */}
        <div className="flex items-center gap-2">
          <button
            onClick={onOpenWhatToStudy}
            className="relative group overflow-hidden px-3.5 py-1.5 sm:px-4 sm:py-2 rounded-xl bg-gradient-to-r from-indigo-600 via-indigo-500 to-violet-600 hover:from-indigo-500 hover:to-violet-500 text-white font-semibold text-xs sm:text-sm shadow-md shadow-indigo-600/30 hover:shadow-indigo-500/50 hover:scale-[1.02] active:scale-[0.98] transition-all flex items-center gap-2 border border-indigo-400/30 cursor-pointer"
          >
            <Sparkles className="w-4 h-4 text-amber-300 animate-pulse" />
            <span className="hidden xs:inline">What should I study now?</span>
            <span className="xs:hidden">Study Now?</span>
            <span className="text-[10px] bg-white/20 text-white px-1.5 py-0.2 rounded font-mono hidden md:inline">
              AI Decision
            </span>
          </button>

          {/* Quick Time Budget Button */}
          <div className="relative hidden md:block">
            <button
              onClick={() => setShowTimeBudgetMenu(!showTimeBudgetMenu)}
              className="px-2.5 py-1.5 rounded-lg border border-slate-700 hover:border-slate-600 bg-slate-900/80 text-xs font-medium text-slate-300 hover:text-white flex items-center gap-1.5 transition-colors"
              title="Time-aware study filter"
            >
              <Clock className="w-3.5 h-3.5 text-indigo-400" />
              <span>
                {profile.quickTimeBudget ? `Today: ${profile.quickTimeBudget}h` : `Max: ${profile.dailyAvailableHours}h`}
              </span>
            </button>

            {showTimeBudgetMenu && (
              <div className="absolute top-full mt-1.5 right-0 w-48 rounded-xl bg-slate-900 border border-slate-800 p-2 shadow-xl z-50">
                <p className="text-[11px] font-semibold text-slate-400 px-2 py-1">Free Time Today:</p>
                <div className="space-y-1">
                  {[1, 2, 3, 4].map((hours) => (
                    <button
                      key={hours}
                      onClick={() => {
                        setTimeBudget(hours);
                        setShowTimeBudgetMenu(false);
                      }}
                      className={`w-full text-left px-2 py-1.5 rounded-lg text-xs font-medium flex items-center justify-between ${
                        profile.quickTimeBudget === hours
                          ? 'bg-indigo-600/20 text-indigo-400 border border-indigo-500/30'
                          : 'text-slate-300 hover:bg-slate-800'
                      }`}
                    >
                      <span>I have {hours} hour{hours > 1 ? 's' : ''}</span>
                      {profile.quickTimeBudget === hours && <span className="text-[10px]">Active</span>}
                    </button>
                  ))}
                  <button
                    onClick={() => {
                      setTimeBudget(null);
                      setShowTimeBudgetMenu(false);
                    }}
                    className="w-full text-left px-2 py-1 rounded-lg text-xs text-slate-400 hover:bg-slate-800"
                  >
                    Reset (Default {profile.dailyAvailableHours}h)
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Right: Energy Selector, Streak, Points, Tour & Tools */}
        <div className="flex items-center gap-2 sm:gap-2.5">
          {/* Energy Mode Selector */}
          <div className="hidden lg:flex items-center rounded-xl bg-slate-900 border border-slate-800 p-0.5">
            {energyOptions.map((opt) => (
              <button
                key={opt.level}
                onClick={() => setEnergyMode(opt.level)}
                className={`px-2.5 py-1 rounded-lg text-xs font-medium flex items-center gap-1.5 transition-all ${
                  profile.currentEnergy === opt.level
                    ? opt.color + ' border font-semibold shadow-sm'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
                }`}
                title={`Study Energy: ${opt.label}`}
              >
                <span>{opt.icon}</span>
                <span className="hidden xl:inline">{opt.label}</span>
              </button>
            ))}
          </div>

          {/* Gamification Streak & Points */}
          <div className="hidden sm:flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-slate-900 border border-slate-800 text-xs">
            <span className="flex items-center gap-1 text-amber-400 font-semibold" title="Daily Study Streak">
              <Flame className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
              {profile.streakDays}d
            </span>
            <span className="text-slate-700">|</span>
            <span className="flex items-center gap-1 text-indigo-400 font-semibold" title="Student XP Points">
              <Award className="w-3.5 h-3.5 text-indigo-400" />
              {profile.studyPoints}
            </span>
          </div>

          {/* Judge Demo Quick Launcher */}
          <button
            onClick={onOpenJudgeTour}
            className="px-2.5 py-1.5 rounded-lg bg-amber-500/10 border border-amber-500/30 text-amber-300 hover:bg-amber-500/20 text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
            title="Launch 2-Minute Hackathon Demo Flow"
          >
            <Zap className="w-3.5 h-3.5 text-amber-400" />
            <span className="hidden md:inline">Judge Demo</span>
          </button>

          {/* Notification Bell */}
          <button
            onClick={onOpenNotifications}
            className="relative p-2 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
            title="Notifications"
          >
            <Bell className="w-4 h-4" />
            {unreadCount > 0 && (
              <span className="absolute top-1 right-1 w-2 h-2 rounded-full bg-rose-500 animate-pulse" />
            )}
          </button>

          {/* Reset Demo Data */}
          <button
            onClick={() => {
              if (window.confirm('Reset StudyPilot state to default hackathon demo scenario?')) {
                resetToDemoData();
              }
            }}
            className="p-2 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors hidden sm:block"
            title="Reset to Demo State"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
        </div>
      </div>
    </header>
  );
};
