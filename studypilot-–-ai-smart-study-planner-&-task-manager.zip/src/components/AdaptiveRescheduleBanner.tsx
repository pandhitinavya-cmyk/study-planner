import React from 'react';
import { RefreshCw, Check, X, Sparkles, Clock, AlertTriangle } from 'lucide-react';
import { useApp } from '../context/AppContext';

export const AdaptiveRescheduleBanner: React.FC = () => {
  const { activeRescheduleEvent, acceptRescheduleProposal, dismissRescheduleProposal, setCurrentView } = useApp();

  if (!activeRescheduleEvent) return null;

  return (
    <div className="relative overflow-hidden mb-6 rounded-2xl bg-gradient-to-r from-amber-950/40 via-indigo-950/50 to-slate-900 border border-amber-500/30 p-4 sm:p-5 shadow-lg shadow-amber-500/5 transition-all">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="flex items-start gap-3">
          <div className="p-2.5 rounded-xl bg-amber-500/20 border border-amber-500/40 text-amber-300 shrink-0 mt-0.5">
            <RefreshCw className="w-5 h-5 animate-spin-slow" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30">
                Adaptive Re-scheduling Engine
              </span>
              <span className="text-[11px] text-slate-400">
                Auto-calculated {activeRescheduleEvent.suggestedAt}
              </span>
            </div>
            <h4 className="text-sm sm:text-base font-semibold text-white mt-1">
              Missed or Incomplete Study Task Detected
            </h4>
            <p className="text-xs sm:text-sm text-slate-300 mt-1 max-w-2xl leading-relaxed">
              {activeRescheduleEvent.message}
            </p>
            <div className="flex flex-wrap items-center gap-3 mt-2 text-xs text-slate-400">
              <span className="flex items-center gap-1 text-slate-400 line-through">
                <Clock className="w-3.5 h-3.5 text-slate-500" />
                Original: {activeRescheduleEvent.originalSlot}
              </span>
              <span className="text-amber-400 font-semibold flex items-center gap-1">
                ➜ New Slot: {activeRescheduleEvent.newSlot}
              </span>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto shrink-0 pt-2 sm:pt-0">
          <button
            onClick={() => acceptRescheduleProposal(activeRescheduleEvent.id)}
            className="flex-1 sm:flex-none px-4 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-indigo-600 hover:from-amber-400 hover:to-indigo-500 text-white font-semibold text-xs sm:text-sm shadow-md shadow-amber-500/20 hover:scale-[1.02] active:scale-[0.98] transition-all flex items-center justify-center gap-1.5 cursor-pointer"
          >
            <Check className="w-4 h-4" />
            <span>Accept New Schedule</span>
          </button>
          <button
            onClick={dismissRescheduleProposal}
            className="p-2 rounded-xl border border-slate-700 hover:border-slate-600 text-slate-400 hover:text-white bg-slate-900/60 transition-colors"
            title="Dismiss proposal"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
