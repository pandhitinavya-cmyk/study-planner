import React from 'react';
import {
  Zap,
  X,
  CheckCircle2,
  Play,
  ArrowRight,
  Sparkles,
  RefreshCw,
  Timer,
  BarChart3,
  BookOpen,
} from 'lucide-react';
import { useApp } from '../context/AppContext';

interface JudgeDemoTourModalProps {
  isOpen: boolean;
  onClose: () => void;
  onTriggerWhatToStudy: () => void;
  onTriggerAiBreakdown: () => void;
}

export const JudgeDemoTourModal: React.FC<JudgeDemoTourModalProps> = ({
  isOpen,
  onClose,
  onTriggerWhatToStudy,
  onTriggerAiBreakdown,
}) => {
  const { setCurrentView, markTaskStatus, tasks, resetToDemoData } = useApp();

  if (!isOpen) return null;

  const demoSteps = [
    {
      num: 1,
      title: 'College Workload Onboarding',
      desc: 'Student inputs subjects, exam dates, daily available hours, and difficulty ratings.',
      actionLabel: 'View Subjects & Exams',
      action: () => {
        setCurrentView('subjects');
        onClose();
      },
    },
    {
      num: 2,
      title: 'Smart Priority Engine',
      desc: 'Transparent formula calculates 🔴 Critical, 🟠 High, 🟡 Medium, 🟢 Low with exact reasons.',
      actionLabel: 'View Task Priorities',
      action: () => {
        setCurrentView('tasks');
        onClose();
      },
    },
    {
      num: 3,
      title: 'AI Smart Planner & Timeline',
      desc: 'Automatically converts deadlines into discrete daily study slots with break buffers.',
      actionLabel: 'View Study Plan',
      action: () => {
        setCurrentView('planner');
        onClose();
      },
    },
    {
      num: 4,
      title: '“What should I study now?” (Highlight)',
      desc: 'Cognitive decision engine synthesizes energy, deadlines, and weak areas in real time.',
      actionLabel: 'Test Decision Engine',
      action: () => {
        onClose();
        onTriggerWhatToStudy();
      },
    },
    {
      num: 5,
      title: 'AI Study Breakdown',
      desc: 'Turns "Prepare for DBMS exam" into actionable subtasks with estimated minutes.',
      actionLabel: 'Try AI Breakdown',
      action: () => {
        onClose();
        onTriggerAiBreakdown();
      },
    },
    {
      num: 6,
      title: 'Adaptive Rescheduling (The Core Innovation)',
      desc: 'If a student misses a task, StudyPilot reorganizes the schedule instead of shaming with overdue tags.',
      actionLabel: 'Simulate Missed Task ➜ Reschedule',
      action: () => {
        // Mark first pending task as partially completed to trigger adaptive rescheduling!
        const target = tasks.find((t) => t.status !== 'completed');
        if (target) {
          markTaskStatus(target.id, 'partially_completed', 35);
        }
        setCurrentView('dashboard');
        onClose();
      },
    },
    {
      num: 7,
      title: 'Focus Mode (Pomodoro & Reflection)',
      desc: 'Distraction-free timer that feeds session completion directly into future scheduling.',
      actionLabel: 'Open Focus Mode',
      action: () => {
        setCurrentView('focus');
        onClose();
      },
    },
    {
      num: 8,
      title: 'Emergency Exam Rescue Mode',
      desc: 'Instant 80/20 non-burnout revision timetable for exams under 7 days away.',
      actionLabel: 'View Exam Rescue',
      action: () => {
        setCurrentView('exams');
        onClose();
      },
    },
    {
      num: 9,
      title: 'Productivity & Consistency Analytics',
      desc: 'Planned vs actual hours, subject radar, streaks, and achievement badges.',
      actionLabel: 'View Analytics',
      action: () => {
        setCurrentView('analytics');
        onClose();
      },
    },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
      <div className="relative w-full max-w-2xl rounded-2xl bg-slate-900 border border-amber-500/30 p-6 shadow-2xl shadow-amber-500/10 max-h-[92vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-800 shrink-0">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-amber-500/20 text-amber-300 border border-amber-500/30">
              <Zap className="w-5 h-5 text-amber-400" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30">
                  Hackathon Judging Tour
                </span>
                <span className="text-xs text-slate-400">2-Minute Demo Workflow</span>
              </div>
              <h3 className="font-bold text-base sm:text-lg text-white mt-0.5">
                StudyPilot Live Evaluation Flow
              </h3>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Core Value Statement Banner */}
        <div className="my-3 p-3.5 rounded-xl bg-gradient-to-r from-indigo-950/60 to-slate-950 border border-indigo-500/20 text-xs text-slate-300 shrink-0">
          <span className="text-amber-300 font-bold">The Hackathon Difference: </span>
          Normal to-do apps tell students <span className="text-white font-semibold">WHAT</span> they have.
          StudyPilot tells students <span className="text-indigo-300 font-semibold">WHAT to study, WHEN to study it, WHY it is critical</span>, and <span className="text-emerald-300 font-semibold">auto-adapts</span> when plans change.
        </div>

        {/* Steps List */}
        <div className="py-2 overflow-y-auto space-y-2.5 pr-1">
          {demoSteps.map((step) => (
            <div
              key={step.num}
              className="p-3 rounded-xl bg-slate-950 border border-slate-800 hover:border-slate-700 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs transition-colors"
            >
              <div className="flex items-start gap-2.5">
                <span className="w-6 h-6 rounded-lg bg-indigo-500/20 text-indigo-400 font-mono font-bold flex items-center justify-center shrink-0 text-xs">
                  {step.num}
                </span>
                <div>
                  <h4 className="font-semibold text-white text-xs sm:text-sm">{step.title}</h4>
                  <p className="text-[11px] text-slate-400 mt-0.5 max-w-md">{step.desc}</p>
                </div>
              </div>

              <button
                onClick={step.action}
                className="w-full sm:w-auto px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-indigo-600 text-slate-200 hover:text-white font-medium text-xs flex items-center justify-center gap-1.5 shrink-0 transition-colors cursor-pointer"
              >
                <span>{step.actionLabel}</span>
                <ArrowRight className="w-3 h-3" />
              </button>
            </div>
          ))}
        </div>

        {/* Footer */}
        <div className="pt-3 border-t border-slate-800 flex items-center justify-between shrink-0">
          <button
            onClick={() => {
              resetToDemoData();
              onClose();
            }}
            className="px-3 py-2 rounded-xl text-xs text-slate-400 hover:text-white flex items-center gap-1.5"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Reset Demo Data</span>
          </button>
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-medium text-xs cursor-pointer"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
