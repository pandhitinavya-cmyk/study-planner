import React, { useState, useMemo } from 'react';
import {
  X,
  Plus,
  Clock,
  Calendar,
  Layers,
  Sparkles,
  AlertCircle,
  Trash2,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { TaskType, PriorityLevel } from '../types';
import { getTodayDateString } from '../utils/demoData';
import { calculateTaskPriority } from '../utils/priorityEngine';

interface AddTaskModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AddTaskModal: React.FC<AddTaskModalProps> = ({ isOpen, onClose }) => {
  const { subjects, exams, addTask } = useApp();

  const [title, setTitle] = useState('');
  const [type, setType] = useState<TaskType>('assignment');
  const [subjectId, setSubjectId] = useState(subjects[0]?.id || '');
  const [deadline, setDeadline] = useState(getTodayDateString(2));
  const [estimatedMinutes, setEstimatedMinutes] = useState(60);
  const [difficulty, setDifficulty] = useState<'easy' | 'medium' | 'hard'>('medium');
  const [importance, setImportance] = useState<'critical' | 'high' | 'medium' | 'low'>('high');
  const [notes, setNotes] = useState('');
  const [subtasks, setSubtasks] = useState<{ id: string; title: string; minutes: number }[]>([]);
  const [newSubtaskTitle, setNewSubtaskTitle] = useState('');

  // Live priority preview
  const priorityPreview = useMemo(() => {
    return calculateTaskPriority(
      {
        deadline,
        difficulty,
        importance,
        estimatedMinutes,
        subjectId,
      },
      subjects,
      exams
    );
  }, [deadline, difficulty, importance, estimatedMinutes, subjectId, subjects, exams]);

  if (!isOpen) return null;

  const handleAddSubtask = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newSubtaskTitle.trim()) return;
    setSubtasks([
      ...subtasks,
      { id: `st-${Date.now()}`, title: newSubtaskTitle.trim(), minutes: 20 },
    ]);
    setNewSubtaskTitle('');
  };

  const handleRemoveSubtask = (id: string) => {
    setSubtasks(subtasks.filter((s) => s.id !== id));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;

    const subject = subjects.find((s) => s.id === subjectId) || subjects[0];

    addTask({
      title: title.trim(),
      type,
      subjectId,
      subjectName: subject.name,
      deadline,
      estimatedMinutes,
      difficulty,
      importance,
      status: 'pending',
      progressPercent: 0,
      scheduledDate: getTodayDateString(0),
      scheduledTimeSlot: '05:00 PM - 06:00 PM',
      notes,
      subtasks: subtasks.map((st) => ({
        id: st.id,
        title: st.title,
        completed: false,
        estimatedMinutes: st.minutes,
      })),
    });

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-fade-in">
      <div className="relative w-full max-w-lg rounded-2xl bg-slate-900 border border-slate-800 p-6 shadow-2xl max-h-[92vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-800 shrink-0">
          <div>
            <h3 className="font-bold text-base sm:text-lg text-white">
              Add Academic Task
            </h3>
            <p className="text-xs text-slate-400">
              Task will be automatically prioritized and scheduled by StudyPilot
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="py-4 overflow-y-auto space-y-3.5 pr-1">
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              Task Title
            </label>
            <input
              type="text"
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g. Implement B-Tree Indexing in Java"
              className="w-full px-3.5 py-2 rounded-xl bg-slate-950 border border-slate-700 focus:border-indigo-500 text-sm text-white placeholder-slate-500"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Category
              </label>
              <select
                value={type}
                onChange={(e) => setType(e.target.value as TaskType)}
                className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-xs text-white"
              >
                <option value="assignment">Assignment</option>
                <option value="project">College Project</option>
                <option value="exam_prep">Exam Prep</option>
                <option value="lab">Lab Record</option>
                <option value="revision">Revision</option>
                <option value="personal">Personal / Other</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Subject
              </label>
              <select
                value={subjectId}
                onChange={(e) => setSubjectId(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-xs text-white"
              >
                {subjects.map((sub) => (
                  <option key={sub.id} value={sub.id}>
                    {sub.name}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Due Date (Deadline)
              </label>
              <input
                type="date"
                required
                value={deadline}
                onChange={(e) => setDeadline(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-xs text-white"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Est. Duration (mins)
              </label>
              <input
                type="number"
                min="15"
                max="360"
                step="15"
                value={estimatedMinutes}
                onChange={(e) => setEstimatedMinutes(Number(e.target.value))}
                className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-xs text-white"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Difficulty Level
              </label>
              <select
                value={difficulty}
                onChange={(e) => setDifficulty(e.target.value as any)}
                className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-xs text-white"
              >
                <option value="easy">Easy (Quick recall / light reading)</option>
                <option value="medium">Medium (Standard exercises)</option>
                <option value="hard">Hard (Complex coding / heavy theory)</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Importance
              </label>
              <select
                value={importance}
                onChange={(e) => setImportance(e.target.value as any)}
                className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-xs text-white"
              >
                <option value="critical">Critical (Heavy grading weight)</option>
                <option value="high">High (Mandatory assignment)</option>
                <option value="medium">Medium (Regular coursework)</option>
                <option value="low">Low (Supplemental study)</option>
              </select>
            </div>
          </div>

          {/* Smart Priority Engine Live Preview */}
          <div className="p-3.5 rounded-xl bg-indigo-950/30 border border-indigo-500/30">
            <div className="flex items-center justify-between">
              <span className="text-[11px] font-bold uppercase tracking-wider text-indigo-300 flex items-center gap-1">
                <Sparkles className="w-3.5 h-3.5 text-amber-300" />
                Auto-Calculated Priority Level:
              </span>
              <span
                className={`text-xs font-bold uppercase px-2 py-0.5 rounded-md ${
                  priorityPreview.priority === 'critical'
                    ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                    : priorityPreview.priority === 'high'
                    ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                    : 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                }`}
              >
                {priorityPreview.priority} (Score: {priorityPreview.score})
              </span>
            </div>
            <p className="text-[11px] text-slate-400 mt-1.5 leading-relaxed">
              <strong>Transparent Reason:</strong> {priorityPreview.reason}
            </p>
          </div>

          {/* Subtasks Section */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              Subtasks / Milestones (Optional)
            </label>
            <div className="flex gap-2 mb-2">
              <input
                type="text"
                value={newSubtaskTitle}
                onChange={(e) => setNewSubtaskTitle(e.target.value)}
                placeholder="Add step (e.g. Write test cases)"
                className="flex-1 px-3 py-1.5 rounded-xl bg-slate-950 border border-slate-700 text-xs text-white"
              />
              <button
                type="button"
                onClick={handleAddSubtask}
                className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-medium text-slate-200"
              >
                + Add Step
              </button>
            </div>

            {subtasks.length > 0 && (
              <div className="space-y-1.5 max-h-28 overflow-y-auto">
                {subtasks.map((st) => (
                  <div
                    key={st.id}
                    className="flex items-center justify-between px-2.5 py-1.5 rounded-lg bg-slate-950 border border-slate-800 text-xs text-slate-300"
                  >
                    <span>• {st.title}</span>
                    <button
                      type="button"
                      onClick={() => handleRemoveSubtask(st.id)}
                      className="text-slate-500 hover:text-rose-400"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="pt-2 border-t border-slate-800 flex items-center justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl text-xs text-slate-400 hover:text-white"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs sm:text-sm shadow-md shadow-indigo-600/30 cursor-pointer"
            >
              Create &amp; Auto-Schedule Task
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
