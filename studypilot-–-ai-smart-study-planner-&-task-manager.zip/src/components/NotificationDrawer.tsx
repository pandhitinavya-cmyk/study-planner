import React from 'react';
import {
  Bell,
  X,
  CheckCircle,
  AlertTriangle,
  Info,
  Flame,
  RefreshCw,
  Trash2,
} from 'lucide-react';
import { useApp } from '../context/AppContext';

interface NotificationDrawerProps {
  isOpen: boolean;
  onClose: () => void;
}

export const NotificationDrawer: React.FC<NotificationDrawerProps> = ({ isOpen, onClose }) => {
  const { notifications, markNotificationRead, clearNotifications, setCurrentView } = useApp();

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-black/60 backdrop-blur-xs animate-fade-in">
      <div className="w-full max-w-sm h-full bg-slate-950 border-l border-slate-800 p-5 flex flex-col justify-between shadow-2xl">
        {/* Header */}
        <div>
          <div className="flex items-center justify-between pb-4 border-b border-slate-800">
            <div className="flex items-center gap-2">
              <Bell className="w-5 h-5 text-indigo-400" />
              <h3 className="font-bold text-white text-base">Smart Notifications</h3>
            </div>
            <button
              onClick={onClose}
              className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <div className="flex items-center justify-between py-2.5 text-xs text-slate-400">
            <span>{notifications.length} alerts</span>
            {notifications.length > 0 && (
              <button
                onClick={clearNotifications}
                className="text-rose-400 hover:underline flex items-center gap-1"
              >
                <Trash2 className="w-3 h-3" /> Clear all
              </button>
            )}
          </div>

          {/* Notifications List */}
          <div className="space-y-2.5 overflow-y-auto max-h-[calc(100vh-160px)] pr-1">
            {notifications.length === 0 ? (
              <div className="py-12 text-center text-slate-500 text-xs">
                No notifications right now. You are all caught up!
              </div>
            ) : (
              notifications.map((n) => {
                const getIcon = () => {
                  if (n.type === 'urgent') return <AlertTriangle className="w-4 h-4 text-rose-400" />;
                  if (n.type === 'reschedule') return <RefreshCw className="w-4 h-4 text-amber-400" />;
                  if (n.type === 'achievement') return <Flame className="w-4 h-4 text-orange-400" />;
                  return <Info className="w-4 h-4 text-sky-400" />;
                };

                return (
                  <div
                    key={n.id}
                    onClick={() => {
                      markNotificationRead(n.id);
                      if (n.actionRoute) {
                        setCurrentView(n.actionRoute);
                        onClose();
                      }
                    }}
                    className={`p-3 rounded-xl border text-xs cursor-pointer transition-all ${
                      n.read
                        ? 'bg-slate-900/40 border-slate-800 text-slate-400'
                        : 'bg-slate-900 border-indigo-500/30 text-slate-200 shadow-sm'
                    }`}
                  >
                    <div className="flex items-start gap-2.5">
                      <div className="p-1 rounded-lg bg-slate-800 shrink-0 mt-0.5">{getIcon()}</div>
                      <div className="flex-1">
                        <div className="flex items-center justify-between gap-1">
                          <h4 className="font-semibold text-white text-xs">{n.title}</h4>
                          <span className="text-[10px] text-slate-500 shrink-0">{n.timestamp}</span>
                        </div>
                        <p className="text-[11px] text-slate-400 mt-1 leading-relaxed">{n.message}</p>
                        {n.actionText && (
                          <span className="inline-block mt-2 text-[10px] font-semibold text-indigo-400 hover:text-indigo-300">
                            {n.actionText} →
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="pt-3 border-t border-slate-800">
          <button
            onClick={onClose}
            className="w-full py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 text-xs font-medium"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
