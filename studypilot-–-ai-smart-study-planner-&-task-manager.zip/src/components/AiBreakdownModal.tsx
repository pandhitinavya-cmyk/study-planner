import React, { useState } from 'react';
import {
  Sparkles,
  X,
  Plus,
  Clock,
  CheckCircle2,
  ListTodo,
  Layers,
  ArrowRight,
  BookOpen,
  AlertCircle,
  Lightbulb,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { getTodayDateString } from '../utils/demoData';

interface AiBreakdownModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AiBreakdownModal: React.FC<AiBreakdownModalProps> = ({ isOpen, onClose }) => {
  const { subjects, addTask, requestTaskBreakdown, setCurrentView } = useApp();

  const [promptInput, setPromptInput] = useState('Prepare for DBMS exam');
  const [selectedSubjectId, setSelectedSubjectId] = useState(subjects[0]?.id || '');
  const [estimatedHours, setEstimatedHours] = useState(3);
  const [loading, setLoading] = useState(false);
  const [breakdownResult, setBreakdownResult] = useState<{
    subtasks: Array<{
      title: string;
      estimatedMinutes: number;
      priority: 'critical' | 'high' | 'medium' | 'low';
      difficulty: 'easy' | 'medium' | 'hard';
      notes?: string;
    }>;
    studyTip: string;
  } | null>(null);

  if (!isOpen) return null;

  const handleGenerate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!promptInput.trim()) return;

    setLoading(true);
    const sub = subjects.find((s) => s.id === selectedSubjectId);
    try {
      const data = await requestTaskBreakdown(promptInput, sub?.name, estimatedHours);
      setBreakdownResult(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleImportToTasks = () => {
    if (!breakdownResult) return;

    const sub = subjects.find((s) => s.id === selectedSubjectId) || subjects[0];

    // Create the master task with subtasks
    addTask({
      title: promptInput,
      type: promptInput.toLowerCase().includes('exam') ? 'exam_prep' : 'project',
      subjectId: sub.id,
      subjectName: sub.name,
      deadline: getTodayDateString(3),
      estimatedMinutes: breakdownResult.subtasks.reduce((sum, s) => sum + s.estimatedMinutes, 0),
      difficulty: 'hard',
      importance: 'high',
      status: 'pending',
      progressPercent: 0,
      scheduledDate: getTodayDateString(0),
      scheduledTimeSlot: '05:00 PM - 07:00 PM',
      subtasks: breakdownResult.subtasks.map((st, idx) => ({
        id: `st-${Date.now()}-${idx}`,
        title: st.title,
        completed: false,
        estimatedMinutes: st.estimatedMinutes,
      })),
      notes: breakdownResult.studyTip,
    });

    onClose();
    setCurrentView('tasks');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-fade-in">
      <div className="relative w-full max-w-xl rounded-2xl bg-slate-900 border border-indigo-500/30 p-6 shadow-2xl shadow-indigo-500/10 max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-800 shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-gradient-to-tr from-indigo-500 to-violet-500 text-white shadow-md shadow-indigo-500/25">
              <Sparkles className="w-5 h-5 text-amber-300" />
            </div>
            <div>
              <h3 className="font-bold text-base sm:text-lg text-white">
                AI Study Breakdown
              </h3>
              <p className="text-xs text-slate-400">
                Decompose big goals into realistic, structured milestones
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="py-4 overflow-y-auto space-y-4">
          <form onSubmit={handleGenerate} className="space-y-3">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Enter study goal or major deliverable:
              </label>
              <div className="relative">
                <input
                  type="text"
                  value={promptInput}
                  onChange={(e) => setPromptInput(e.target.value)}
                  placeholder="e.g. Prepare for DBMS exam, Complete Cloud Computing Paper"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-700 focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 text-sm text-white placeholder-slate-500 transition-all"
                  required
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Target Subject:
                </label>
                <select
                  value={selectedSubjectId}
                  onChange={(e) => setSelectedSubjectId(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-xs text-white focus:border-indigo-500"
                >
                  {subjects.map((sub) => (
                    <option key={sub.id} value={sub.id}>
                      {sub.name} ({sub.code})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Estimated Total Hours:
                </label>
                <input
                  type="number"
                  min="1"
                  max="20"
                  value={estimatedHours}
                  onChange={(e) => setEstimatedHours(Number(e.target.value))}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-xs text-white focus:border-indigo-500"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full py-2.5 px-4 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs sm:text-sm shadow-md shadow-indigo-600/30 flex items-center justify-center gap-2 cursor-pointer transition-all"
            >
              <Sparkles className="w-4 h-4 text-amber-300" />
              <span>{loading ? 'Decomposing Syllabus Topics...' : 'Generate AI Subtask Breakdown'}</span>
            </button>
          </form>

          {/* Breakdown Results */}
          {breakdownResult && (
            <div className="space-y-3 pt-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
                  <Layers className="w-3.5 h-3.5 text-indigo-400" />
                  Generated Structured Subtasks ({breakdownResult.subtasks.length})
                </span>
                <span className="text-[11px] text-slate-400">
                  Total: {breakdownResult.subtasks.reduce((sum, s) => sum + s.estimatedMinutes, 0)} mins
                </span>
              </div>

              <div className="space-y-2 max-h-56 overflow-y-auto pr-1">
                {breakdownResult.subtasks.map((st, i) => (
                  <div
                    key={i}
                    className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex items-start justify-between gap-3 text-xs"
                  >
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="font-semibold text-white">{st.title}</span>
                      </div>
                      {st.notes && <p className="text-[11px] text-slate-400">{st.notes}</p>}
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      <span className="px-2 py-0.5 rounded-md bg-slate-800 text-slate-300 font-mono text-[10px]">
                        {st.estimatedMinutes}m
                      </span>
                      <span
                        className={`px-1.5 py-0.5 rounded-md font-semibold text-[10px] uppercase ${
                          st.priority === 'critical'
                            ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                            : st.priority === 'high'
                            ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                            : 'bg-indigo-500/20 text-indigo-300 border border-indigo-500/30'
                        }`}
                      >
                        {st.priority}
                      </span>
                    </div>
                  </div>
                ))}
              </div>

              {/* Study Tip */}
              {breakdownResult.studyTip && (
                <div className="p-3 rounded-xl bg-indigo-950/40 border border-indigo-500/20 flex items-start gap-2.5 text-xs text-indigo-200">
                  <Lightbulb className="w-4 h-4 text-amber-300 shrink-0 mt-0.5" />
                  <div>
                    <span className="font-bold text-amber-300">Study Strategy: </span>
                    <span>{breakdownResult.studyTip}</span>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Footer */}
        {breakdownResult && (
          <div className="pt-3 border-t border-slate-800 flex items-center justify-end gap-2 shrink-0">
            <button
              onClick={onClose}
              className="px-3 py-2 rounded-xl text-xs text-slate-400 hover:text-white"
            >
              Cancel
            </button>
            <button
              onClick={handleImportToTasks}
              className="py-2 px-4 rounded-xl bg-gradient-to-r from-emerald-600 to-indigo-600 hover:from-emerald-500 hover:to-indigo-500 text-white font-semibold text-xs sm:text-sm shadow-md shadow-indigo-600/20 flex items-center gap-2 cursor-pointer"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>Import as New Task with Subtasks</span>
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
