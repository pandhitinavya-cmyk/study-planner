import React, { useState, useEffect } from 'react';
import {
  Sparkles,
  X,
  Play,
  Clock,
  AlertCircle,
  CheckCircle2,
  Brain,
  Zap,
  Target,
  ArrowRight,
  RefreshCw,
} from 'lucide-react';
import { useApp } from '../context/AppContext';

interface WhatShouldIStudyNowModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const WhatShouldIStudyNowModal: React.FC<WhatShouldIStudyNowModalProps> = ({
  isOpen,
  onClose,
}) => {
  const { getWhatShouldIStudyNow, startFocusMode, profile, tasks } = useApp();
  const [loading, setLoading] = useState(false);
  const [recommendation, setRecommendation] = useState<any>(null);

  const fetchDecision = async () => {
    setLoading(true);
    try {
      const result = await getWhatShouldIStudyNow();
      setRecommendation(result);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (isOpen) {
      fetchDecision();
    }
  }, [isOpen, profile.currentEnergy, profile.quickTimeBudget]);

  if (!isOpen) return null;

  const handleStartFocus = () => {
    onClose();
    // Find task if exists or pass recommended title
    const matchedTask = tasks.find(
      (t) =>
        t.id === recommendation?.taskId ||
        t.title.toLowerCase().includes(recommendation?.recommendedTask?.toLowerCase() || '')
    );
    startFocusMode(matchedTask ? matchedTask.id : undefined);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-fade-in">
      <div className="relative w-full max-w-lg rounded-2xl bg-slate-900 border border-indigo-500/30 p-6 sm:p-7 shadow-2xl shadow-indigo-500/10 overflow-hidden">
        {/* Glow backdrop effects */}
        <div className="absolute -top-24 -right-24 w-48 h-48 rounded-full bg-indigo-500/20 blur-3xl pointer-events-none" />
        <div className="absolute -bottom-24 -left-24 w-48 h-48 rounded-full bg-violet-500/20 blur-3xl pointer-events-none" />

        {/* Modal Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-800 relative z-10">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-gradient-to-tr from-indigo-500 to-violet-500 text-white shadow-md shadow-indigo-500/30">
              <Sparkles className="w-5 h-5 text-amber-300" />
            </div>
            <div>
              <h3 className="font-bold text-base sm:text-lg text-white">
                What Should I Study Right Now?
              </h3>
              <p className="text-xs text-slate-400">
                AI Cognitive Decision Engine
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="py-5 relative z-10">
          {loading ? (
            <div className="py-12 flex flex-col items-center justify-center gap-3 text-center">
              <div className="relative">
                <RefreshCw className="w-8 h-8 text-indigo-400 animate-spin" />
                <Sparkles className="w-4 h-4 text-amber-300 absolute -top-1 -right-1 animate-pulse" />
              </div>
              <div>
                <p className="text-sm font-semibold text-white">
                  Synthesizing Academic Priorities...
                </p>
                <p className="text-xs text-slate-400 mt-0.5">
                  Analyzing deadline urgency + exam proximity + energy mode ({profile.currentEnergy})
                </p>
              </div>
            </div>
          ) : recommendation ? (
            <div className="space-y-4">
              {/* Highlight Card */}
              <div className="p-4 rounded-xl bg-gradient-to-b from-indigo-950/60 to-slate-900/90 border border-indigo-500/40 relative">
                <div className="flex items-center justify-between gap-2 mb-2">
                  <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-md bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                    {recommendation.subject || 'Academic Target'}
                  </span>
                  <div className="flex items-center gap-1.5 text-xs font-semibold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-md border border-emerald-500/20">
                    <Clock className="w-3.5 h-3.5" />
                    <span>{recommendation.suggestedMinutes || 40} Mins</span>
                  </div>
                </div>

                <h4 className="text-base sm:text-lg font-bold text-white leading-snug">
                  {recommendation.recommendedTask}
                </h4>

                <div className="mt-3 pt-3 border-t border-slate-800/80 flex items-start gap-2 text-xs text-slate-300">
                  <Target className="w-4 h-4 text-indigo-400 shrink-0 mt-0.5" />
                  <div>
                    <span className="font-semibold text-indigo-300">Why now: </span>
                    <span>{recommendation.reason}</span>
                  </div>
                </div>
              </div>

              {/* Actionable First Step */}
              <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 flex items-start gap-3">
                <div className="p-1.5 rounded-lg bg-amber-500/10 text-amber-300 border border-amber-500/20 shrink-0 mt-0.5">
                  <Zap className="w-4 h-4" />
                </div>
                <div>
                  <h5 className="text-xs font-bold text-amber-300 uppercase tracking-wide">
                    Immediate 5-Minute Kickoff
                  </h5>
                  <p className="text-xs text-slate-300 mt-0.5">
                    {recommendation.firstStep || 'Open the syllabus notes and review key formula definitions.'}
                  </p>
                </div>
              </div>

              {/* Energy & Time Context */}
              <div className="flex items-center justify-between text-xs text-slate-400 px-1">
                <span>
                  Energy: <strong className="text-slate-200 capitalize">{profile.currentEnergy}</strong>
                </span>
                <span>
                  Budget: <strong className="text-slate-200">{profile.quickTimeBudget || profile.dailyAvailableHours}h today</strong>
                </span>
              </div>
            </div>
          ) : null}
        </div>

        {/* Modal Footer */}
        <div className="flex items-center justify-between gap-3 pt-3 border-t border-slate-800 relative z-10">
          <button
            onClick={fetchDecision}
            disabled={loading}
            className="px-3 py-2 rounded-xl border border-slate-700 hover:border-slate-600 text-xs font-medium text-slate-300 hover:text-white transition-colors flex items-center gap-1.5 cursor-pointer"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Re-evaluate</span>
          </button>

          <button
            onClick={handleStartFocus}
            disabled={loading}
            className="flex-1 py-2.5 px-4 rounded-xl bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-500 hover:to-violet-500 text-white font-semibold text-xs sm:text-sm shadow-md shadow-indigo-600/30 hover:scale-[1.02] active:scale-[0.98] transition-all flex items-center justify-center gap-2 cursor-pointer"
          >
            <Play className="w-4 h-4 fill-white" />
            <span>Start Focus Session Now</span>
          </button>
        </div>
      </div>
    </div>
  );
};
