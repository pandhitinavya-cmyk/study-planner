import React, { useState, useEffect } from 'react';
import {
  ShieldAlert,
  X,
  Sparkles,
  Calendar,
  Clock,
  BookOpen,
  CheckCircle2,
  AlertTriangle,
  HeartPulse,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { Exam } from '../types';

interface ExamRescueModalProps {
  exam: Exam | null;
  isOpen: boolean;
  onClose: () => void;
}

export const ExamRescueModal: React.FC<ExamRescueModalProps> = ({ exam, isOpen, onClose }) => {
  const { requestExamRescue, toggleExamRescueMode, profile } = useApp();
  const [loading, setLoading] = useState(false);
  const [rescuePlanData, setRescuePlanData] = useState<any>(null);

  useEffect(() => {
    if (isOpen && exam) {
      loadRescuePlan();
    }
  }, [isOpen, exam]);

  const loadRescuePlan = async () => {
    if (!exam) return;
    setLoading(true);
    try {
      const data = await requestExamRescue(exam, profile.dailyAvailableHours);
      setRescuePlanData(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  if (!isOpen || !exam) return null;

  const handleActivate = () => {
    toggleExamRescueMode(exam.id);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
      <div className="relative w-full max-w-2xl rounded-2xl bg-slate-900 border border-rose-500/40 p-6 shadow-2xl shadow-rose-500/10 max-h-[92vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-800 shrink-0">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-rose-500/20 text-rose-300 border border-rose-500/30">
              <ShieldAlert className="w-6 h-6 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-rose-500/20 text-rose-300 border border-rose-500/30">
                  Exam Rescue Mode
                </span>
                <span className="text-xs text-rose-400 font-semibold">
                  {exam.daysRemaining} Days Remaining
                </span>
              </div>
              <h3 className="font-bold text-lg text-white mt-0.5">
                {exam.title}
              </h3>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="py-4 overflow-y-auto space-y-4 pr-1">
          {loading ? (
            <div className="py-16 text-center space-y-3">
              <ShieldAlert className="w-10 h-10 text-rose-400 animate-spin-slow mx-auto" />
              <p className="text-sm font-semibold text-white">
                Generating High-Yield Revision Timetable...
              </p>
              <p className="text-xs text-slate-400">
                Balancing 80/20 rule topics, spaced retention drills, and rest buffers.
              </p>
            </div>
          ) : rescuePlanData ? (
            <>
              {/* Emergency Banner */}
              <div className="p-3.5 rounded-xl bg-gradient-to-r from-rose-950/40 to-slate-950 border border-rose-500/30 text-xs text-rose-200 flex items-start gap-3">
                <HeartPulse className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
                <div>
                  <h4 className="font-bold text-rose-300 text-sm">Non-Burnout Guarantee</h4>
                  <p className="mt-0.5 leading-relaxed text-slate-300">
                    Rescue mode caps daily study to {profile.dailyAvailableHours} hours and enforces 15-minute restorative breaks to maximize recall under exam pressure.
                  </p>
                </div>
              </div>

              {/* Revision Timetable */}
              <div>
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-300 mb-2 flex items-center gap-2">
                  <Calendar className="w-4 h-4 text-rose-400" />
                  Structured Timetable
                </h4>
                <div className="space-y-3">
                  {rescuePlanData.rescuePlan?.map((dayPlan: any, i: number) => (
                    <div key={i} className="p-3.5 rounded-xl bg-slate-950 border border-slate-800">
                      <div className="flex items-center justify-between mb-2 pb-2 border-b border-slate-800/80">
                        <span className="font-bold text-rose-400 text-xs">{dayPlan.day}</span>
                        <span className="text-xs text-slate-300 font-medium">{dayPlan.focusTheme}</span>
                      </div>
                      <div className="space-y-2">
                        {dayPlan.sessions?.map((sess: any, sIdx: number) => (
                          <div
                            key={sIdx}
                            className="flex items-center justify-between p-2 rounded-lg bg-slate-900/60 border border-slate-800 text-xs"
                          >
                            <div>
                              <div className="font-semibold text-white">{sess.topic}</div>
                              <span className="text-[11px] text-slate-400 flex items-center gap-1.5 mt-0.5">
                                <Clock className="w-3 h-3 text-indigo-400" />
                                {sess.timeSlot} • Technique: {sess.technique}
                              </span>
                            </div>
                            <span className="px-2 py-0.5 rounded-md bg-rose-500/10 text-rose-300 font-mono text-[10px] shrink-0">
                              {sess.durationMinutes}m
                            </span>
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* High Yield Checklist */}
              {rescuePlanData.highYieldChecklist && (
                <div>
                  <h4 className="text-xs font-bold uppercase tracking-wider text-slate-300 mb-2 flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                    High-Yield 80/20 Checklist
                  </h4>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    {rescuePlanData.highYieldChecklist.map((item: string, idx: number) => (
                      <div
                        key={idx}
                        className="p-2.5 rounded-lg bg-slate-950 border border-slate-800 text-xs text-slate-300 flex items-start gap-2"
                      >
                        <span className="text-emerald-400 font-bold">✓</span>
                        <span>{item}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Emergency Rules */}
              {rescuePlanData.emergencyAdvice && (
                <div className="p-3 rounded-xl bg-amber-950/30 border border-amber-500/20 text-xs text-amber-200">
                  <span className="font-bold text-amber-300">Exam Strategy Rules: </span>
                  <span>{rescuePlanData.emergencyAdvice}</span>
                </div>
              )}
            </>
          ) : null}
        </div>

        {/* Footer */}
        <div className="pt-3 border-t border-slate-800 flex items-center justify-between shrink-0">
          <button
            onClick={onClose}
            className="px-3 py-2 rounded-xl text-xs text-slate-400 hover:text-white"
          >
            Close
          </button>
          <button
            onClick={handleActivate}
            className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-rose-600 to-indigo-600 hover:from-rose-500 hover:to-indigo-500 text-white font-semibold text-xs sm:text-sm shadow-md shadow-rose-600/30 flex items-center gap-2 cursor-pointer"
          >
            <ShieldAlert className="w-4 h-4" />
            <span>
              {exam.rescueModeActive ? 'Rescue Mode Active (Click to Re-lock)' : 'Activate Rescue Mode for this Exam'}
            </span>
          </button>
        </div>
      </div>
    </div>
  );
};
