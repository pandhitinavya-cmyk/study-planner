import React from 'react';
import {
  LayoutDashboard,
  CheckSquare,
  CalendarDays,
  BookOpen,
  GraduationCap,
  Timer,
  BarChart3,
  User,
  Zap,
  Sparkles,
  Info,
  X,
  ShieldAlert,
} from 'lucide-react';
import { useApp } from '../context/AppContext';

interface SidebarProps {
  mobileOpen: boolean;
  onCloseMobile: () => void;
  onOpenTaskModal: () => void;
  onOpenAiBreakdown: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  mobileOpen,
  onCloseMobile,
  onOpenTaskModal,
  onOpenAiBreakdown,
}) => {
  const { currentView, setCurrentView, tasks, exams } = useApp();

  const pendingTaskCount = tasks.filter((t) => t.status !== 'completed').length;
  const upcomingExamCount = exams.filter((e) => e.daysRemaining <= 7).length;

  const navItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'tasks', label: 'My Tasks & Projects', icon: CheckSquare, badge: pendingTaskCount },
    { id: 'planner', label: 'Study Plan', icon: CalendarDays },
    { id: 'subjects', label: 'Subjects & Weak Areas', icon: BookOpen },
    { id: 'exams', label: 'Exams & Rescue Mode', icon: GraduationCap, badge: upcomingExamCount > 0 ? `${upcomingExamCount} urgent` : undefined, badgeColor: 'bg-rose-500/20 text-rose-300 border-rose-500/30' },
    { id: 'focus', label: 'Focus Mode (Pomodoro)', icon: Timer },
    { id: 'analytics', label: 'Analytics & Streak', icon: BarChart3 },
    { id: 'profile', label: 'Profile & Settings', icon: User },
    { id: 'landing', label: 'Overview & Tour', icon: Info },
  ];

  const handleNav = (id: string) => {
    setCurrentView(id);
    onCloseMobile();
  };

  return (
    <>
      {/* Mobile backdrop */}
      {mobileOpen && (
        <div
          className="fixed inset-0 bg-black/60 z-40 lg:hidden backdrop-blur-xs"
          onClick={onCloseMobile}
        />
      )}

      <aside
        className={`fixed lg:sticky top-0 lg:top-[57px] left-0 z-50 lg:z-10 h-screen lg:h-[calc(100vh-57px)] w-64 bg-slate-950 border-r border-slate-800 flex flex-col justify-between p-4 transition-transform duration-200 ease-in-out ${
          mobileOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
        }`}
      >
        <div className="flex flex-col gap-5 overflow-y-auto pr-1">
          {/* Mobile Header Close */}
          <div className="flex items-center justify-between lg:hidden pb-2 border-b border-slate-800">
            <span className="font-bold text-white text-sm">StudyPilot Navigation</span>
            <button
              onClick={onCloseMobile}
              className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Quick Action Buttons */}
          <div className="space-y-2">
            <button
              onClick={() => {
                onOpenTaskModal();
                onCloseMobile();
              }}
              className="w-full py-2.5 px-3 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs flex items-center justify-center gap-2 shadow-sm shadow-indigo-600/30 transition-all cursor-pointer"
            >
              <Zap className="w-4 h-4 text-amber-300" />
              <span>+ Quick Add Task</span>
            </button>
            <button
              onClick={() => {
                onOpenAiBreakdown();
                onCloseMobile();
              }}
              className="w-full py-2 px-3 rounded-xl bg-slate-900 hover:bg-slate-800/80 border border-indigo-500/30 hover:border-indigo-500/60 text-indigo-300 font-medium text-xs flex items-center justify-center gap-2 transition-all cursor-pointer"
            >
              <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
              <span>AI Task Breakdown</span>
            </button>
          </div>

          {/* Main Navigation Links */}
          <nav className="space-y-1">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = currentView === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => handleNav(item.id)}
                  className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-semibold transition-all ${
                    isActive
                      ? 'bg-indigo-600/15 text-indigo-400 border border-indigo-500/30 font-bold shadow-sm'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <Icon className={`w-4 h-4 ${isActive ? 'text-indigo-400' : 'text-slate-400'}`} />
                    <span>{item.label}</span>
                  </div>
                  {item.badge !== undefined && (
                    <span
                      className={`text-[10px] px-2 py-0.5 rounded-full font-mono border ${
                        item.badgeColor || 'bg-slate-800 text-slate-300 border-slate-700'
                      }`}
                    >
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </nav>
        </div>

        {/* Hackathon Differentiator Card */}
        <div className="mt-4 p-3 rounded-xl bg-gradient-to-b from-indigo-950/40 to-slate-900 border border-indigo-500/20">
          <div className="flex items-center gap-1.5 mb-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
            <span className="text-[10px] font-bold uppercase tracking-wider text-indigo-300">
              Adaptive Engine
            </span>
          </div>
          <p className="text-[11px] text-slate-300 leading-snug">
            Unlike static to-do lists, StudyPilot calculates <span className="text-white font-semibold">what</span>, <span className="text-white font-semibold">when</span>, &amp; <span className="text-white font-semibold">why</span> to study.
          </p>
        </div>
      </aside>
    </>
  );
};
