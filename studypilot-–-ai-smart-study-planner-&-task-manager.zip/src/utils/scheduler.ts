import { Task, Subject, Exam, StudySession, StudentProfile, EnergyLevel, AdaptiveRescheduleEvent } from '../types';
import { getTodayDateString } from './demoData';
import { calculateTaskPriority } from './priorityEngine';

interface GenerateScheduleParams {
  tasks: Task[];
  subjects: Subject[];
  exams: Exam[];
  profile: StudentProfile;
  targetDate?: string;
}

export function generateSmartSchedule({
  tasks,
  subjects,
  exams,
  profile,
  targetDate = getTodayDateString(0),
}: GenerateScheduleParams): StudySession[] {
  // Filter active pending / in_progress tasks
  const pendingTasks = tasks.filter((t) => t.status !== 'completed');

  // Recalculate priorities
  const scoredTasks = pendingTasks.map((task) => {
    const { score, priority, reason } = calculateTaskPriority(task, subjects, exams);
    return {
      ...task,
      priorityScore: score,
      calculatedPriority: priority,
      priorityReason: reason,
    };
  });

  // Sort based on Priority + Energy
  scoredTasks.sort((a, b) => {
    if (profile.currentEnergy === 'high') {
      // Weight difficulty more in high energy
      const aWeight = a.priorityScore + (a.difficulty === 'hard' ? 20 : 0);
      const bWeight = b.priorityScore + (b.difficulty === 'hard' ? 20 : 0);
      return bWeight - aWeight;
    }
    if (profile.currentEnergy === 'low') {
      // Prioritize manageable tasks when tired
      const aWeight = a.priorityScore - (a.difficulty === 'hard' ? 30 : 0) + (a.difficulty === 'easy' ? 25 : 0);
      const bWeight = b.priorityScore - (b.difficulty === 'hard' ? 30 : 0) + (b.difficulty === 'easy' ? 25 : 0);
      return bWeight - aWeight;
    }
    return b.priorityScore - a.priorityScore;
  });

  // Calculate total available minutes for the target date
  let totalMinutesAvailable = Math.round((profile.quickTimeBudget || profile.dailyAvailableHours) * 60);

  // Time slot starting base according to preferred study time
  let startHour = 17; // default 5:00 PM for evening
  if (profile.preferredStudyTime === 'morning') startHour = 9;
  if (profile.preferredStudyTime === 'afternoon') startHour = 14;
  if (profile.preferredStudyTime === 'night') startHour = 20;

  let currentMinuteOffset = startHour * 60;
  const sessions: StudySession[] = [];
  let allocatedMinutes = 0;

  for (const task of scoredTasks) {
    if (allocatedMinutes >= totalMinutesAvailable) break;

    const taskSubject = subjects.find((s) => s.id === task.subjectId);
    const duration = Math.min(task.estimatedMinutes, totalMinutesAvailable - allocatedMinutes, 90);

    if (duration < 15) break;

    const startH = Math.floor(currentMinuteOffset / 60);
    const startM = currentMinuteOffset % 60;
    const endOffset = currentMinuteOffset + duration;
    const endH = Math.floor(endOffset / 60);
    const endM = endOffset % 60;

    const formatTime = (h: number, m: number) => {
      const period = h >= 12 ? 'PM' : 'AM';
      const displayH = h % 12 === 0 ? 12 : h % 12;
      return `${String(displayH).padStart(2, '0')}:${String(m).padStart(2, '0')} ${period}`;
    };

    const timeSlotString = `${formatTime(startH, startM)} - ${formatTime(endH, endM)}`;

    sessions.push({
      id: `session-${task.id}-${Date.now().toString(36)}`,
      taskId: task.id,
      taskTitle: task.title,
      subjectName: task.subjectName,
      subjectColor: taskSubject?.color || '#6366f1',
      date: targetDate,
      startTime: `${String(startH).padStart(2, '0')}:${String(startM).padStart(2, '0')}`,
      endTime: `${String(endH).padStart(2, '0')}:${String(endM).padStart(2, '0')}`,
      timeSlotString,
      durationMinutes: duration,
      isCompleted: false,
    });

    allocatedMinutes += duration;
    // Add 15-min cognitive break buffer between study sessions
    currentMinuteOffset = endOffset + 15;
  }

  return sessions;
}

export function createAdaptiveRescheduleProposal(
  missedTask: Task,
  existingSessions: StudySession[],
  profile: StudentProfile
): AdaptiveRescheduleEvent {
  const originalSlot = missedTask.scheduledTimeSlot || 'Yesterday 05:00 PM';
  const newStartHour = profile.preferredStudyTime === 'morning' ? '10:00 AM' : '07:30 PM';
  const newEndHour = profile.preferredStudyTime === 'morning' ? '11:00 AM' : '08:30 PM';
  const newSlot = `Today ${newStartHour} - ${newEndHour}`;

  return {
    id: `reschedule-${Date.now()}`,
    missedTaskId: missedTask.id,
    taskTitle: missedTask.title,
    originalSlot,
    newSlot,
    reason: `Incomplete session detected. Re-balanced into today's ${profile.preferredStudyTime} study block without overcrowding your exam preparation.`,
    message: `"${missedTask.title}" was not completed. StudyPilot moved it to ${newSlot} and preserved your high-priority exam revisions.`,
    suggestedAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
  };
}
