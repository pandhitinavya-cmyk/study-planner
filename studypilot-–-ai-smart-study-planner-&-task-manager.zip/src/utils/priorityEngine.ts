import { PriorityLevel, Subject, Exam, EnergyLevel } from '../types';

export interface PriorityCalculationResult {
  priority: PriorityLevel;
  score: number;
  reason: string;
}

export function calculateTaskPriority(
  task: {
    deadline: string;
    difficulty: 'easy' | 'medium' | 'hard';
    importance: 'critical' | 'high' | 'medium' | 'low';
    estimatedMinutes: number;
    subjectId: string;
  },
  subjects: Subject[],
  exams: Exam[]
): PriorityCalculationResult {
  let score = 0;
  const reasons: string[] = [];

  // 1. Deadline urgency
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const taskDeadline = new Date(task.deadline);
  taskDeadline.setHours(0, 0, 0, 0);
  const diffDays = Math.ceil((taskDeadline.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));

  if (diffDays <= 0) {
    score += 45;
    reasons.push('Due today or overdue');
  } else if (diffDays === 1) {
    score += 38;
    reasons.push('Due tomorrow');
  } else if (diffDays <= 3) {
    score += 26;
    reasons.push(`Due in ${diffDays} days`);
  } else if (diffDays <= 7) {
    score += 15;
    reasons.push(`Due in ${diffDays} days`);
  } else {
    score += 5;
    reasons.push('Due next week+');
  }

  // 2. Importance
  if (task.importance === 'critical') {
    score += 30;
    reasons.push('Vital course deliverable');
  } else if (task.importance === 'high') {
    score += 20;
    reasons.push('High assignment weight');
  } else if (task.importance === 'medium') {
    score += 10;
  } else {
    score += 5;
  }

  // 3. Difficulty
  if (task.difficulty === 'hard') {
    score += 20;
    reasons.push('Challenging technical topic');
  } else if (task.difficulty === 'medium') {
    score += 10;
  } else {
    score += 4;
  }

  // 4. Estimated time required
  if (task.estimatedMinutes >= 90) {
    score += 14;
    reasons.push(`${Math.round(task.estimatedMinutes / 60)}h estimated effort`);
  } else if (task.estimatedMinutes >= 45) {
    score += 8;
  } else {
    score += 4;
  }

  // 5. Subject context (Weak subject or Exam approaching)
  const subject = subjects.find((s) => s.id === task.subjectId);
  if (subject?.isWeakSubject) {
    score += 18;
    reasons.push('Weak subject needing reinforcement');
  }

  const relatedExam = exams.find((e) => e.subjectId === task.subjectId);
  if (relatedExam) {
    const examDate = new Date(relatedExam.examDate);
    const examDiffDays = Math.ceil((examDate.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
    if (examDiffDays <= 5 && examDiffDays >= 0) {
      score += 25;
      reasons.push(`${relatedExam.title} in ${examDiffDays} days`);
    } else if (examDiffDays <= 14 && examDiffDays >= 0) {
      score += 12;
      reasons.push(`Upcoming exam countdown`);
    }
  }

  let priority: PriorityLevel = 'low';
  if (score >= 80) priority = 'critical';
  else if (score >= 55) priority = 'high';
  else if (score >= 32) priority = 'medium';
  else priority = 'low';

  const readableReason = `${priority.toUpperCase()} PRIORITY — ${reasons.slice(0, 3).join(' + ')}.`;

  return {
    priority,
    score,
    reason: readableReason,
  };
}

export function filterTasksByEnergy(
  tasks: Array<{ difficulty: 'easy' | 'medium' | 'hard'; estimatedMinutes: number }>,
  energy: EnergyLevel
) {
  if (energy === 'high') {
    // High energy: prioritize hard / deep work tasks
    return [...tasks].sort((a, b) => (b.difficulty === 'hard' ? 1 : 0) - (a.difficulty === 'hard' ? 1 : 0));
  }
  if (energy === 'low') {
    // Low energy: prioritize easy / bite-sized review tasks
    return [...tasks].sort((a, b) => (a.difficulty === 'easy' ? -1 : 1) - (b.difficulty === 'easy' ? -1 : 1));
  }
  return tasks;
}
