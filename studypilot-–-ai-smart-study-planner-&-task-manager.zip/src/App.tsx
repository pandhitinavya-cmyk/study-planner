import React, { useState } from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Navbar } from './components/Navbar';
import { Sidebar } from './components/Sidebar';
import { WhatShouldIStudyNowModal } from './components/WhatShouldIStudyNowModal';
import { AddTaskModal } from './components/AddTaskModal';
import { AiBreakdownModal } from './components/AiBreakdownModal';
import { JudgeDemoTourModal } from './components/JudgeDemoTourModal';
import { NotificationDrawer } from './components/NotificationDrawer';

import { DashboardView } from './views/DashboardView';
import { TasksView } from './views/TasksView';
import { PlannerView } from './views/PlannerView';
import { SubjectsView } from './views/SubjectsView';
import { ExamsView } from './views/ExamsView';
import { FocusView } from './views/FocusView';
import { AnalyticsView } from './views/AnalyticsView';
import { ProfileView } from './views/ProfileView';
import { LandingView } from './views/LandingView';

const MainApp: React.FC = () => {
  const { currentView, theme } = useApp();

  // Modals state
  const [whatToStudyOpen, setWhatToStudyOpen] = useState(false);
  const [addTaskOpen, setAddTaskOpen] = useState(false);
  const [aiBreakdownOpen, setAiBreakdownOpen] = useState(false);
  const [judgeTourOpen, setJudgeTourOpen] = useState(false);
  const [notificationsOpen, setNotificationsOpen] = useState(false);
  const [mobileNavOpen, setMobileNavOpen] = useState(false);

  const renderCurrentView = () => {
    switch (currentView) {
      case 'dashboard':
        return (
          <DashboardView
            onOpenWhatToStudy={() => setWhatToStudyOpen(true)}
            onOpenAddTask={() => setAddTaskOpen(true)}
            onOpenAiBreakdown={() => setAiBreakdownOpen(true)}
          />
        );
      case 'tasks':
        return (
          <TasksView
            onOpenAddTask={() => setAddTaskOpen(true)}
            onOpenAiBreakdown={() => setAiBreakdownOpen(true)}
          />
        );
      case 'planner':
        return <PlannerView onOpenWhatToStudy={() => setWhatToStudyOpen(true)} />;
      case 'subjects':
        return <SubjectsView />;
      case 'exams':
        return <ExamsView />;
      case 'focus':
        return <FocusView />;
      case 'analytics':
        return <AnalyticsView />;
      case 'profile':
        return <ProfileView />;
      case 'landing':
        return (
          <LandingView
            onOpenWhatToStudy={() => setWhatToStudyOpen(true)}
            onOpenJudgeTour={() => setJudgeTourOpen(true)}
          />
        );
      default:
        return (
          <DashboardView
            onOpenWhatToStudy={() => setWhatToStudyOpen(true)}
            onOpenAddTask={() => setAddTaskOpen(true)}
            onOpenAiBreakdown={() => setAiBreakdownOpen(true)}
          />
        );
    }
  };

  return (
    <div className={`min-h-screen ${theme === 'dark' ? 'bg-slate-950 text-slate-100' : 'bg-slate-900 text-white'} flex flex-col font-sans selection:bg-indigo-500 selection:text-white`}>
      {/* Top Navigation */}
      <Navbar
        onOpenWhatToStudy={() => setWhatToStudyOpen(true)}
        onOpenJudgeTour={() => setJudgeTourOpen(true)}
        onToggleMobileNav={() => setMobileNavOpen(!mobileNavOpen)}
        onOpenNotifications={() => setNotificationsOpen(true)}
      />

      {/* Main Content Layout with Sidebar */}
      <div className="flex-1 flex max-w-7xl w-full mx-auto">
        <Sidebar
          mobileOpen={mobileNavOpen}
          onCloseMobile={() => setMobileNavOpen(false)}
          onOpenTaskModal={() => setAddTaskOpen(true)}
          onOpenAiBreakdown={() => setAiBreakdownOpen(true)}
        />

        <main className="flex-1 p-4 sm:p-6 lg:p-8 max-w-5xl overflow-x-hidden">
          {renderCurrentView()}
        </main>
      </div>

      {/* Global Modals & Drawers */}
      <WhatShouldIStudyNowModal
        isOpen={whatToStudyOpen}
        onClose={() => setWhatToStudyOpen(false)}
      />

      <AddTaskModal
        isOpen={addTaskOpen}
        onClose={() => setAddTaskOpen(false)}
      />

      <AiBreakdownModal
        isOpen={aiBreakdownOpen}
        onClose={() => setAiBreakdownOpen(false)}
      />

      <JudgeDemoTourModal
        isOpen={judgeTourOpen}
        onClose={() => setJudgeTourOpen(false)}
        onTriggerWhatToStudy={() => setWhatToStudyOpen(true)}
        onTriggerAiBreakdown={() => setAiBreakdownOpen(true)}
      />

      <NotificationDrawer
        isOpen={notificationsOpen}
        onClose={() => setNotificationsOpen(false)}
      />
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <MainApp />
    </AppProvider>
  );
}
